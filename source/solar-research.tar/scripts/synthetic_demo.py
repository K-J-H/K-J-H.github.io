"""Generate an explicitly synthetic fixture and run the real baseline pipeline."""
import argparse,json
from pathlib import Path
import numpy as np
from solar_research.cli import run,digest
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args()
if a.output.exists():raise SystemExit('OUTPUT_MUST_NOT_EXIST')
a.output.mkdir(parents=True)
y,x=np.mgrid[:128,:128];clean=80+150*np.exp(-((x-64)**2+(y-64)**2)/300)
rng=np.random.default_rng(2026);rates=np.maximum(clean[None,None,:,:]+rng.normal(0,8,(16,1,128,128)),0).astype('float32')
source=a.output/'synthetic-input.npz';np.savez_compressed(source,rates_dn_s=rates,valid=np.ones((1,128,128),bool),halo_valid=np.ones((1,128,128),bool),seconds=np.arange(16)*12.)
report=run(source,digest(source),a.output/'baseline')
report['data_kind']='synthetic_fixture';report['limitations']=['Synthetic fixture, not a solar observation or a neural quality benchmark.','Difference is not accuracy.']
(a.output/'baseline/report.json').write_text(json.dumps(report,indent=2)+'\n')
(a.output/'SYNTHETIC.json').write_text(json.dumps({'data_kind':'synthetic_fixture','seed':2026,'purpose':'installation and protocol demonstration','report':'baseline/report.json'},indent=2)+'\n')
print(json.dumps({'status':'PASS','data_kind':'synthetic_fixture','output':str(a.output)}))
