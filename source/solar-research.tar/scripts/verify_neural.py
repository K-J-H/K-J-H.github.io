"""Explicit integration check: requires real pinned assets; never silently skipped."""
import argparse,json
from pathlib import Path
import numpy as np
from solar_research.cli import load_observation, digest
import solar_research.neural as neural
from solar_research.neural import SpatialModel, run

p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True);p.add_argument('--models',type=Path,required=True);p.add_argument('--output',type=Path,required=True)
a=p.parse_args(); sha='ed1400d58a77f1bb3d1675baba01b82b34620d0845a0d7935c30d7a90758c6c6'
path=a.assets/'2024-03-01.npz'; cp=a.models/'checkpoint.pt'; protocol=a.models/'protocol.json'
raw,keep,_=load_observation(path,sha,0,7)
vendor=Path(neural.__file__).parent/'vendor'
assert digest(vendor/'shine.py')==neural.MANIFEST['adapted_source_sha256']
assert 'Copyright (c) 2025 Jungwon Park Lab' in (vendor/'LICENSE-SHINE.txt').read_text()
model=SpatialModel(cp,protocol)
assert model.torch.version.cuda is None and not model.torch.cuda.is_available()
y=model.predict(raw); z=model.predict(raw)
np.testing.assert_array_equal(y,z)
assert np.isfinite(y).all() and y.shape==(64,64)
assert not np.allclose(y,raw[32:96,32:96])
assert not np.allclose(y,model.predict(raw*0.5))
try: SpatialModel(cp,path)
except ValueError as e: assert 'CHECKSUM' in str(e)
else: raise AssertionError('Wrong protocol was accepted')
report=run(path,sha,cp,protocol,a.output)
with np.load(a.output/'result.npz') as result: np.testing.assert_array_equal(result['shine_dn_s'],y)
assert report['method_kind']=='neural_model' and 'psnr' not in report
print(json.dumps({'status':'PASS','checks':['pinned assets','strict weights','cpu only','repeatability','input sensitivity','protocol rejection','saved result equality'],'report':report}))
