import hashlib
import json
import numpy as np
import pytest
from solar_research.cli import load_observation,run


def sample(tmp_path):
    path=tmp_path/'synthetic-fixture.npz'
    rates=np.full((16,1,128,128),10,dtype=np.float32)
    rates[:,0,64,64]=110
    np.savez_compressed(path,rates_dn_s=rates,valid=np.ones((1,128,128),bool),halo_valid=np.ones((1,128,128),bool),seconds=np.arange(16)*12.)
    return path,hashlib.sha256(path.read_bytes()).hexdigest()


def test_reproducible_real_processing(tmp_path):
    path,sha=sample(tmp_path)
    a=run(path,sha,tmp_path/'a');b=run(path,sha,tmp_path/'b')
    x=np.load(tmp_path/'a/result.npz');y=np.load(tmp_path/'b/result.npz')
    np.testing.assert_allclose(x['gaussian_dn_s'],y['gaussian_dn_s'],rtol=0,atol=0)
    assert 10 < x['gaussian_dn_s'][32,32] < 110
    assert abs(float((x['gaussian_dn_s']-10).sum())-100)<0.001
    assert a['method_kind']=='classical_baseline' and 'psnr' not in a
    assert (tmp_path/'a/comparison.png').is_file()
    assert a['result_sha256']==hashlib.sha256((tmp_path/'a/result.npz').read_bytes()).hexdigest()


def test_reject_checksum_and_overwrite(tmp_path):
    path,sha=sample(tmp_path)
    with pytest.raises(ValueError,match='CHECKSUM'):run(path,'0'*64,tmp_path/'bad')
    run(path,sha,tmp_path/'out')
    with pytest.raises(ValueError,match='NOT_EMPTY'):run(path,sha,tmp_path/'out')


def test_reject_outside_registered_target(tmp_path):
    path,sha=sample(tmp_path)
    with pytest.raises(ValueError,match='TARGET'):load_observation(path,sha,0,0)


def test_reject_bad_cadence(tmp_path):
    path,sha=sample(tmp_path)
    with np.load(path) as d: values={k:d[k] for k in d.files}
    values['seconds'][1]=0
    np.savez_compressed(path,**values)
    with pytest.raises(ValueError,match='CADENCE'):load_observation(path,hashlib.sha256(path.read_bytes()).hexdigest(),0,7)
