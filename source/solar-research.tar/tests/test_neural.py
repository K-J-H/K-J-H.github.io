import numpy as np
import pytest
from solar_research.neural import SpatialModel


def test_reject_checkpoint_before_deserialization(tmp_path):
    cp=tmp_path/'untrusted.pt'; cp.write_bytes(b'not a checkpoint')
    with pytest.raises(ValueError,match='CHECKSUM'):
        SpatialModel(cp, tmp_path/'absent.json')


@pytest.mark.parametrize('raw', [np.zeros((64,64)), np.full((128,128),np.nan), np.full((128,128),-1)])
def test_reject_invalid_input_before_model_call(raw):
    model=SpatialModel.__new__(SpatialModel)
    with pytest.raises(ValueError,match='128_DN_S'):
        model.predict(raw)
