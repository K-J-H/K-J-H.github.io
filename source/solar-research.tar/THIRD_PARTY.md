# SHINE attribution

Architecture: Jungwon Park Lab, MIT license (2025).
Source: https://github.com/jungwonparklab/SHINE/tree/a89831dde44aacd1b040eab66ab0af52176d7ece
Vendored file: src/solar_research/vendor/shine.py; license included beside it and in the installed wheel.
Local adaptation removes one CUDA autocast decorator and normalizes line endings/trailing whitespace; architecture/parameter names unchanged. CPU uses float32. Hashes are in src/solar_research/model-manifest.json.
The checkpoint comes from the user's existing solar research run, not the upstream pretrained distribution. Weight and sample files remain private local assets. This adapter does not establish public redistribution clearance for those assets.
