# 实现说明

输入协议 → Gaussian或固定SHINE → 科学数组/同尺度PNG/报告。源码cli.py负责数据与基线，neural.py负责固定CPU模型，vendor保留MIT来源，scripts提供合成和真实权重入口。

系统性原理与从零命令见 [README](../README.md) / [English](../README.en.md)。遵循既有架构，不顺手重构无关模块；新增功能先补README、实现与测试约定再执行。破坏性数据操作或依赖大版本升级先确认。
