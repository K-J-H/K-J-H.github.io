"""CPU observation baseline; never labels smoothed data as neural inference."""
import argparse
import hashlib
import json
import time
import zipfile
from pathlib import Path
import numpy as np
from scipy.ndimage import gaussian_filter
from PIL import Image


def digest(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def load_observation(path, expected_sha, crop, target):
    if len(expected_sha) != 64 or digest(path) != expected_sha:
        raise ValueError('ASSET_CHECKSUM_MISMATCH')
    with zipfile.ZipFile(path) as z:
        if sum(i.file_size for i in z.infolist()) > 128 * 1024**2:
            raise ValueError('DATA_TOO_LARGE')
    with np.load(path, allow_pickle=False) as data:
        rates, valid, halo, seconds = (data[k] for k in ('rates_dn_s','valid','halo_valid','seconds'))
    if rates.ndim != 4 or rates.shape[0] != 16 or rates.shape[2:] != (128,128):
        raise ValueError('EXPECTED_16_FRAMES_128_CONTEXT')
    if valid.shape != rates.shape[1:] or halo.shape != valid.shape or valid.dtype != bool or halo.dtype != bool:
        raise ValueError('INVALID_MASK')
    if seconds.shape != (16,) or not np.isfinite(seconds).all() or not np.all((np.diff(seconds)>11)&(np.diff(seconds)<13)):
        raise ValueError('INVALID_CADENCE')
    if not 0 <= crop < rates.shape[1] or not 4 <= target < 12:
        raise ValueError('INVALID_CROP_OR_TARGET')
    if not np.isfinite(rates[:,crop][:,valid[crop]]).all() or (rates[:,crop][:,valid[crop]]<0).any():
        raise ValueError('INVALID_OBSERVATIONS')
    keep = halo[crop,32:96,32:96]
    if keep.sum() < 3000 or np.any(halo[crop] & ~valid[crop]):
        raise ValueError('INSUFFICIENT_VALID_CORE')
    return np.where(valid[crop], rates[target,crop], 0).astype(np.float32), keep, float(seconds[target])


def run(path, sha, output, crop=0, target=7):
    output=Path(output)
    if output.exists() and any(output.iterdir()):
        raise ValueError('OUTPUT_NOT_EMPTY')
    raw, keep, seconds=load_observation(path,sha,crop,target)
    started=time.perf_counter()
    filtered=gaussian_filter(raw, sigma=1.0, mode='reflect')
    before, after=raw[32:96,32:96], filtered[32:96,32:96]
    if not np.isfinite(after).all(): raise ValueError('NONFINITE_OUTPUT')
    output.mkdir(parents=True,exist_ok=True)
    np.savez_compressed(output/'result.npz',input_dn_s=before,gaussian_dn_s=after,valid=keep)
    lo,hi=np.percentile(before[keep],[1,99])
    def preview(a):
        return (np.clip((a-lo)/max(float(hi-lo),1e-6),0,1)*255).astype(np.uint8)
    # Same display scale on both panels, unrelated to scientific data normalization.
    Image.fromarray(np.concatenate([preview(before),preview(after)],axis=1)).resize((768,384),Image.Resampling.NEAREST).save(output/'comparison.png')
    report={'schema_version':1,'method':'gaussian_sigma1','method_kind':'classical_baseline','device':'cpu',
        'input_sha256':sha,'crop':crop,'target_frame':target,'seconds_from_first':seconds,'unit':'DN/s',
        'input_shape':[128,128],'output_shape':[64,64],'valid_core_pixels':int(keep.sum()),
        'difference_rmse_dn_s':float(np.sqrt(np.mean((after[keep]-before[keep])**2))),
        'mean_change_dn_s':float(np.mean(after[keep]-before[keep])),
        'elapsed_seconds':time.perf_counter()-started,'result_sha256':digest(output/'result.npz'),
        'display':{'left':'original observation','right':'Gaussian sigma1','shared_percentiles':[float(lo),float(hi)]},
        'limitations':['Not a neural model.','No clean reference: difference is not denoising accuracy.','Sample is previously evaluated development data, not a fresh holdout.','Saturation positions are not fully certified.']}
    (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',required=True,type=Path)
    parser.add_argument('--sha256',required=True)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--crop',type=int,default=0)
    parser.add_argument('--target',type=int,default=7)
    args=parser.parse_args()
    try: report=run(args.input,args.sha256,args.output,args.crop,args.target)
    except (ValueError,KeyError,OSError,zipfile.BadZipFile) as exc: parser.exit(2,str(exc)+'\n')
    print(json.dumps(report,allow_nan=False))

if __name__=='__main__':main()
