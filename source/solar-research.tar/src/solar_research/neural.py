"""Pinned SHINE spatial checkpoint, CPU-only inference on solar DN/s observations."""
import argparse
import json
import time
from pathlib import Path
import numpy as np
from PIL import Image
from .cli import digest, load_observation

MANIFEST = json.loads(Path(__file__).with_name('model-manifest.json').read_text())


class SpatialModel:
    def __init__(self, checkpoint, protocol):
        # Verify before deserializing; never accept arbitrary uploaded checkpoints.
        for path, key in [(checkpoint, 'checkpoint_sha256'), (protocol, 'protocol_sha256')]:
            if digest(path) != MANIFEST[key]:
                raise ValueError('MODEL_ASSET_CHECKSUM_MISMATCH')
        import torch
        from .vendor.shine import SHINE
        torch.set_num_threads(2)
        self.torch = torch
        cp = torch.load(checkpoint, map_location='cpu', weights_only=True)
        if cp['step'] != MANIFEST['steps'] or cp['protocol_sha256'] != MANIFEST['protocol_sha256']:
            raise ValueError('CHECKPOINT_PROTOCOL_MISMATCH')
        self.model = SHINE(1, 1, add_dilation=(1, 1), frame_num=1, filter=64, blocks=14, Bias=False)
        self.model.load_state_dict(cp['model'], strict=True)
        self.model.cpu().float().eval()
        if sum(x.numel() for x in self.model.parameters()) != MANIFEST['parameters']:
            raise ValueError('MODEL_ARCHITECTURE_MISMATCH')
        if not all(torch.isfinite(x).all() for x in self.model.parameters()):
            raise ValueError('NONFINITE_WEIGHTS')

    def predict(self, raw):
        raw = np.asarray(raw)
        if raw.shape != (128, 128) or not np.isfinite(raw).all() or (raw < 0).any():
            raise ValueError('EXPECTED_FINITE_NONNEGATIVE_128_DN_S')
        x = np.ascontiguousarray(raw, dtype=np.float32)[None, None] / 1000.0
        with self.torch.inference_mode():
            result = self.model(self.torch.from_numpy(x))
            result = result[0, 0, 32:96, 32:96].numpy().copy() * 1000.0
        if result.shape != (64, 64) or not np.isfinite(result).all():
            raise ValueError('INVALID_MODEL_OUTPUT')
        return result


def run(path, sha, checkpoint, protocol, output, crop=0, target=7):
    output = Path(output)
    if output.exists() and any(output.iterdir()):
        raise ValueError('OUTPUT_NOT_EMPTY')
    raw, keep, seconds = load_observation(path, sha, crop, target)
    started = time.perf_counter()
    model = SpatialModel(checkpoint, protocol)
    loaded = time.perf_counter()
    after = model.predict(raw)
    finished = time.perf_counter()
    before = raw[32:96, 32:96]
    output.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(output/'result.npz', input_dn_s=before, shine_dn_s=after, valid=keep)
    lo, hi = np.percentile(before[keep], [1, 99])
    def preview(a):
        return (np.clip((a-lo)/max(float(hi-lo), 1e-6), 0, 1)*255).astype(np.uint8)
    canvas = np.concatenate([preview(before), preview(after)], axis=1)
    Image.fromarray(canvas).resize((768,384), Image.Resampling.NEAREST).save(output/'comparison.png')
    report = {
        'schema_version':1, 'method':MANIFEST['model_id'], 'method_kind':'neural_model',
        'device':'cpu', 'precision':'float32', 'torch_version':model.torch.__version__,
        'cuda_available':model.torch.cuda.is_available(), 'input_sha256':sha,
        'checkpoint_sha256':MANIFEST['checkpoint_sha256'], 'protocol_sha256':MANIFEST['protocol_sha256'],
        'crop':crop, 'target_frame':target, 'seconds_from_first':seconds, 'unit':'DN/s',
        'input_shape':[128,128], 'output_shape':[64,64], 'valid_core_pixels':int(keep.sum()),
        'difference_rmse_dn_s':float(np.sqrt(np.mean((after[keep]-before[keep])**2))),
        'load_seconds':loaded-started, 'inference_seconds':finished-loaded,
        'result_sha256':digest(output/'result.npz'),
        'display':{'left':'original observation', 'right':'SHINE spatial seed2026', 'shared_percentiles':[float(lo),float(hi)]},
        'limitations':['No clean reference: change is not denoising accuracy.',
          'Previously evaluated development sample, not a fresh holdout.',
          'CPU float32 adaptation; not numerically certified against GPU mixed precision.',
          'No claim of outperforming Gaussian or other methods.',
          'Single-frame solar EUV DN/s only; not arbitrary RGB uploads.',
          'Saturation positions are not fully certified.']}
    (output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    return report


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ['input','checkpoint','protocol','output']:
        parser.add_argument('--'+name, type=Path, required=True)
    parser.add_argument('--sha256', required=True)
    parser.add_argument('--crop', type=int, default=0)
    parser.add_argument('--target', type=int, default=7)
    args=parser.parse_args()
    report=run(args.input,args.sha256,args.checkpoint,args.protocol,args.output,args.crop,args.target)
    print(json.dumps(report,allow_nan=False))

if __name__=='__main__': main()
