# 太阳图像去噪：可核验的 CPU 研究演示

[English](README.en.md) · [模型来源与许可](THIRD_PARTY.md) · [运行与迁移](docs/RUNBOOK.md)

**目的：让“模型实际做了什么”能够被复算，而不只展示一张更平滑的图片。** 本项目从在研的太阳图像去噪课题抽取最小推理链路，提供传统高斯基线、固定 SHINE 单帧检查点的 CPU 推理、输入校验和科学数组导出。它是研究复现与工程适配项目，论文仍在修改。

## 招聘者可快速查看的内容

- 计算机视觉：处理观测掩码、物理单位、上下文裁剪和训练/评价边界。
- 模型工程：固定架构与权重、CPU 推理、精确依赖和可校验的结果产物。
- 科学判断：没有干净真值时不编造 PSNR；当前窄探针没有证明时空网络优于高斯对照。
- 可验证交付：`scripts/verify_neural.py` 检查真实权重、重复性和输入敏感性；`tests/` 覆盖输入和协议错误。

原课题有 3 种输入配置 × 3 个种子的训练记录，每个 6,000 步。本包只运行一个已登记的空间模型，不包含重新训练九个模型的入口。SHINE 架构来自作者 MIT 代码；新增适配、验证、打包与服务集成使用 AI 辅助开发，不宣称架构原创或商业上线。

## 从零运行：不需要私有数据的路径

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

锁文件面向 Linux x86_64 / Python 3.12。离线安装可在第一条 pip 命令增加 `--no-index --find-links var/wheels`，wheel 仍须匹配锁内哈希。首次使用需要系统已有 Python 3.12 和 venv 支持。不要复制旧虚拟环境，也不要借用其他项目的解释器。

在仓库根目录运行：

```bash
.venv/bin/python scripts/synthetic_demo.py --output var/synthetic-first
```

该命令生成明确标注的合成输入并执行真实高斯计算，输出 `baseline/comparison.png`、`baseline/result.npz`、`baseline/report.json` 和 `SYNTHETIC.json`。它验证安装、输入协议和输出流程，**不是太阳观测、不是神经网络质量证据**。输出目录必须不存在；重复运行请用新名字。

## 运行真实 SHINE 检查点

1. 按 `sample-manifest.json` 准备获准使用的观测文件；按 `src/solar_research/model-manifest.json` 准备检查点与协议。文件暂未公开随源码分发，不承诺克隆后即可获得权重。
2. 分别放入 `var/assets/2024-03-01.npz`、`var/models/checkpoint.pt` 及`var/models/protocol.json` 协议文件。
3. 从已核验的离线 wheel 集安装 CPU 附加依赖，或先按锁从 PyPI / PyTorch 官方 CPU 索引下载相应 wheel；不要移除哈希校验来“解决”版本不可用。

```bash
.venv/bin/python -m pip install --no-index --find-links var/wheels --find-links var/cpu-wheels --require-hashes -r requirements-cpu.lock
.venv/bin/python scripts/verify_neural.py --assets var/assets --models var/models --output var/neural-first
```

真实输入 SHA256：`ed1400d58a77f1bb3d1675baba01b82b34620d0845a0d7935c30d7a90758c6c6`。检查点 SHA256：`a22f2eddf968231c8c40887a4bf522406ac3817e7186a13c3fe5843ba242d4f5`。缺失或不匹配会失败，不能用随机权重替换后宣称复现。

## 原理：从观测到可解释产物

### 1. 问题与可识别的结论

观测可理解为真实信号叠加噪声，但真实太阳没有配对的干净标签。自监督方法通过观测本身构造学习约束；训练目标值下降不直接证明物理信号保留。这里将模型推理与科学评价分开：推理回答“固定模型输出什么”，已知增量响应审计回答“加入的可控微弱变化能否被保留”。后者也不等于所有真实信号的恢复精度。

### 2. 输入协议先于模型

NPZ 保存 `rates_dn_s`、`valid`、`halo_valid`、`seconds`。数据形状为 `[16, crops, 128, 128]`，单位 DN/s；相邻时间间隔在 11–13 秒范围内。先验证文件哈希，再检查形状、非负有效值、有限性和掩码包含关系。仅允许目标帧 4–11，中心有效区域至少 3,000 像素。这样避免“模型可以运行，但输入含义已改变”。

### 3. 两条实际计算路径

高斯基线对 128×128 输入做 sigma=1 的反射边界滤波。神经路径将 DN/s 除以 1000，送入固定 SHINE 空间架构，严格匹配检查点，再把输出乘回 1000。模型采用 CPU float32、评估模式及 inference mode；`torch.load(weights_only=True)` 仅加载核验权重。128×128 上下文输出取中心 64×64，使上下文边界与评价区域分开。

### 4. 产物与指标

数组保留物理值及有效掩码；PNG 仅使用同一百分位显示尺度辅助比较。`difference_rmse_dn_s` 是输出和原观测之差，不是相对真值的 RMSE。报告同时保存输入/输出哈希、目标帧、有效像素数和耗时，允许从网页结果追溯到同一输入与权重。

```text
登记资产 → 哈希/协议/掩码检查 → 固定高斯或 SHINE → 中心裁剪
                                             ↓
                               科学数组 + 同色阶 PNG + JSON 报告
```

## 验证与限制

基础测试和真实权重一致性、同机新目录/新 venv 恢复已通过；可按上述命令重新验证当前版本。跨机器、容器、GPU 混合精度一致性尚未验收。本样例是已经使用的开发日期，不是新保留集。FITS 摄取和完整训练属于原课题范围，本包从准备好的 NPZ 开始。
