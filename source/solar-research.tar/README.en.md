# Solar denoising: a verifiable CPU research demo

[中文](README.md) · [Third-party attribution](THIRD_PARTY.md) · [Migration](docs/RUNBOOK.md)

This project makes a fixed scientific inference pipeline inspectable: validated observations, a Gaussian baseline, a real SHINE spatial checkpoint, scientific arrays, comparable previews and traceable reports. The underlying master's research and manuscript remain in progress.

For reviewers, the main evidence is not a visually smooth image: it is the input protocol, fixed weights, masks and units, repeatable inference, and explicit limits on scientific conclusions. The original research has records for three input configurations and three seeds, each trained for 6,000 steps. This package exposes one registered spatial model; it does not reproduce the full training study. SHINE is third-party MIT architecture. Adaptation, packaging and tests were developed with AI assistance, not claimed as an original architecture or commercial deployment.

## Install and verify from scratch

Tested target: Linux x86_64 with Python 3.12 and venv support. In this repository:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

For an offline installation, add `--no-index --find-links var/wheels` to the dependency installation command and supply the exact locked wheels. Recreate the environment; do not copy an old venv or use a sibling project's interpreter.

## Run without private assets

```bash
.venv/bin/python scripts/synthetic_demo.py --output var/synthetic-first
```

This creates an explicitly labelled synthetic fixture and runs actual Gaussian computation. Inspect `baseline/comparison.png`, `baseline/result.npz`, `baseline/report.json` and `SYNTHETIC.json`. The fixture verifies installation and the protocol; it is not solar data or a neural quality benchmark. Use a new output directory on each run.

## Run the registered neural model

Obtain permitted copies matching `sample-manifest.json` and `src/solar_research/model-manifest.json`. Data and weights are not distributed in the public source package. Place the observation in `var/assets/2024-03-01.npz`, and the checkpoint/protocol in `var/models` using the manifest filenames. Then:

```bash
.venv/bin/python -m pip install --no-index --find-links var/wheels --find-links var/cpu-wheels --require-hashes -r requirements-cpu.lock
.venv/bin/python scripts/verify_neural.py --assets var/assets --models var/models --output var/neural-first
```

The wheel cache must contain the exact locked PyPI and official PyTorch CPU wheels. Missing assets or mismatched hashes fail explicitly; random weights are not a substitute for replication.

## How it works, in order

1. **Scientific question.** Real observations lack paired clean targets. Self-supervised learning derives training constraints from observations; a lower training loss does not establish physical signal preservation. A known-increment response audit asks a narrower question than clean-image accuracy.
2. **Input contract.** NPZ contains `rates_dn_s`, `valid`, `halo_valid`, `seconds`. Shape is `[16, crops, 128, 128]`, physical units DN/s, cadence 11–13 seconds. Hash, dimensions, masks, finite/nonnegative valid samples, target indices 4–11 and at least 3,000 valid central pixels are checked before computation.
3. **Inference.** The baseline uses Gaussian sigma=1 with reflected boundaries. The SHINE adapter divides by 1000, runs fixed spatial weights in CPU float32 evaluation/inference mode, then multiplies by 1000. Strict state matching and `weights_only=True` loading follow hash verification. The 128×128 context is cropped to a 64×64 evaluation core.
4. **Outputs.** NPZ preserves physical arrays and masks. PNG uses the same display scale for input and output. The JSON report records hashes, frame, valid count and timing. `difference_rmse_dn_s` measures change from the noisy observation, not error against clean truth.
5. **Verification.** Unit tests reject invalid inputs. The real integration verifier checks architecture, checkpoint, provenance, repeatability and input sensitivity. A fresh local environment has reproduced outputs; cross-machine, container and GPU equivalence are not verified.

The example date is previously used development data, not a fresh holdout. The existing narrow-probe study did not show temporal networks outperforming the Gaussian control. FITS ingestion and full training remain outside this inference package.
