# 技术文档与实验助手

[English](README.en.md) · [运行与迁移](docs/RUNBOOK.md) · [测试说明](docs/TESTING.md)

**回答能找到原文，实验状态能查询，模型费用有记录。** 面向这组视觉项目的双语文档，提供版本化检索引用、可选的受约束模型生成和只读任务查询。默认检索模式不需要模型账户、不产生模型费用。

## 招聘者与技术评审可以看到什么

- 检索不是预写答案：中文双字/英文词切分，BM25 排序，返回真实段落和文件版本。
- 工具不是任意执行器：只查询配置好的视觉服务、携带访问令牌，不让模型执行命令或写文件。
- 预算不是界面上的数字：SQLite 原子预留、实际费用结算、持久请求编号、超时保守记账。
- 19 项测试覆盖引用、版本、并发预算、重复计费防护和错误处理。真实外部模型验收需要提供商账户，当前不声称已经通过。

本项目为个人原型，AI 辅助开发；不把本地小型语料检索当作企业知识库规模或完整自主 Agent。

## 从零启动：无需密钥

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

锁文件面向 Linux x86_64 / Python 3.12。离线安装可在第一条 pip 命令增加 `--no-index --find-links var/wheels`，wheel 仍须匹配锁内哈希。首次使用需要系统已有 Python 3.12 和 venv 支持。不要复制旧虚拟环境，也不要借用其他项目的解释器。

```bash
.venv/bin/python -m docs_assistant.api --data-root var/data ingest --source examples/documents
VISION_API_ORIGIN=http://127.0.0.1:8001 .venv/bin/python -m docs_assistant.api --data-root var/data serve --port 8003
```

另一个终端发送：

```bash
curl -s http://127.0.0.1:8003/api/v1/chat -H 'Content-Type: application/json' -d '{"message":"为什么太阳模型只接受登记样例？","locale":"zh-CN","generate":false}'
```

查看 `mode=retrieval_only`、`citations` 的段落/版本和 `usage.model_calls=0`。`/docs` 为接口说明；`/api/v1/sources/{id}` 可追溯旧版本原文。实验查询需要视觉服务已运行，并使用创建任务时的 Bearer 令牌；没有视觉服务不影响文档检索。

## 可选模型配置

适配器面向支持 JSON 输出的 HTTPS Chat Completions 接口；不是所有供应商都已验收。只在本机配置下列变量，不把密钥提交 Git 或放进网页：

| 变量 | 含义 |
| --- | --- |
| LLM_KEY_FILE | 仅当前用户可读的密钥文件路径 |
| LLM_CHAT_URL | 完整 HTTPS chat completions 端点，不允许重定向 |
| LLM_MODEL | 提供商模型名称 |
| LLM_INPUT_CNY_PER_MILLION | 经核实的每百万输入 token 人民币单价 |
| LLM_OUTPUT_CNY_PER_MILLION | 经核实的每百万输出 token 人民币单价 |
| LLM_MONTHLY_CNY | 应用月上限，默认 25，最大 30 |

服务启动后可在请求中使用 `generate=true`。先以少量测试核对返回格式、真实引用和账单；未配置价格/密钥不能算完成真实生成验收。应用账本仅覆盖此实例经过适配器的调用，不限制同一个供应商账户的其他应用消费；供应商侧也应设置可用的账户限额。

## 原理：检索、生成和查询分别负责什么

### 1. 文档如何成为稳定引用

导入最多 100 个 Markdown 文件，每个不超过 256 KiB。按空行分段，每段最多 6,000 字符；文件 SHA256 是版本号，文档名+版本+段号生成引用 ID。新导入事务原子切换 active 标志，旧段落继续保留，因此过去回答的引用不会无声指向新文本。拒绝符号链接和越界路径。

### 2. 为什么能检索到相关段落

英文按字母数字词，中文按相邻双字切分；去停用词后使用 BM25 风格评分。对每个查询词 t 累加：

`log(1 + (N-df+0.5)/(df+0.5)) * f*2.2 / (f + 1.2*(0.25+0.75*L/avgL))`

N 为段落数，df 为含该词的段落数，f 为段落内词频，L 为段落长度。逆文档频率减少常见词权重，长度归一化避免长段落天然占优。取前三个正分段落；当前是词法检索，不声称实现了向量语义理解。低相关的词碰撞仍可能发生，需要评价集约束。

### 3. 生成为什么必须依附证据

仅在有引用、启用生成且配置完整时调用模型。系统指令把检索材料标为不可信引用数据，模型必须返回 JSON 的 answer 与 citation_ids。应用校验 ID 全部属于本次检索结果，不允许伪造出处；原文和回答分别展示。引用合法不代表回答语义一定正确，仍需人工抽查与真实模型评价，不能据结构校验宣称“消灭幻觉”。

### 4. 如何避免重复花费

调用前按 UTF-8 请求字节数加安全余量估算输入上界、最多 512 个输出 token，原子预留费用。相同 request_id 与相同内容返回缓存，换内容返回冲突；异常/超时保留全额预留并禁止同编号重发。重启在取得独占锁后将未完成预留改为 uncertain，不释放可能已经消费的预算。返回实际 token 用量后结算；若实际费用超过预留，记录费用并阻止后续调用等待价格审查。这个机制依赖正确供应商单价，不是对外部账单的绝对保证。

### 5. 实验工具的权限边界

`GET /api/v1/experiments/{id}` 只向服务器配置的视觉 origin 查询。用户不能指定任意 URL，ID 必须为 32 位十六进制，令牌仅透传给固定服务；重定向禁止。工具返回 allowlist 字段和 read_only 标志，不把令牌传入模型上下文。工具查询由用户明确触发，不宣称模型自主选择工具。

```text
Markdown → 版本化段落 → BM25 top-3 → 原文引用（默认、免费）
                                   └→ 预算预留 → 模型 JSON → 引用校验 → 结算
浏览器任务令牌 ──────────────────────→ 固定视觉服务的只读查询
```

## 验证与限制

运行 `pytest` 检查代码契约，运行 `scripts/evaluate.py` 检查公开语料中的可回答与无依据问题。模型单测使用明确的测试替身，只证明代码分支，不代表真实供应商效果。未连接提供商时不会伪造自然语言生成成功。无登录、无公网防滥用设施的本地服务不要直接裸露到公网。
