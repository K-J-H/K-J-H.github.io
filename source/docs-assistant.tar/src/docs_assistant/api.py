"""Versioned retrieval with optional grounded generation and read-only experiment queries."""
import argparse
from collections import Counter
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sqlite3
from typing import Literal
from fastapi import FastAPI, HTTPException,Header
from contextlib import asynccontextmanager
import fcntl,uuid
from .generation import Settings,Generator,GenerationError
from .experiments import read_experiment,ExperimentError
from pydantic import BaseModel,Field

STOP={'the','a','an','is','are','what','how','does','do','to','of','and','in','for','can','i','with','的','是','吗','什么','如何','可以','是否'}

def tokens(text):
    english=re.findall(r'[a-z0-9]+',text.lower())
    chinese=[]
    for run in re.findall(r'[\u4e00-\u9fff]+',text):
        chinese.extend(run[i:i+2] for i in range(len(run)-1))
    return [x for x in english+chinese if x not in STOP]


class Corpus:
    def __init__(self,root):
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True);self.db=self.root/'corpus.sqlite3'
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS chunks(id TEXT PRIMARY KEY,document TEXT NOT NULL,version TEXT NOT NULL,ordinal INTEGER NOT NULL,text TEXT NOT NULL,active INTEGER NOT NULL)')
    def connect(self):
        db=sqlite3.connect(self.db,timeout=10);db.row_factory=sqlite3.Row;return db
    def ingest(self,source):
        source=Path(source).resolve();files=sorted(source.rglob('*.md'))
        if not files or len(files)>100:raise ValueError('EXPECTED_1_TO_100_MARKDOWN_FILES')
        chunks=[];versions={}
        for file in files:
            if file.is_symlink() or not file.resolve().is_relative_to(source):raise ValueError('SOURCE_SYMLINK_REJECTED')
            raw=file.read_bytes()
            if len(raw)>256*1024:raise ValueError('DOCUMENT_TOO_LARGE')
            text=raw.decode('utf-8');doc=file.relative_to(source).as_posix();version=hashlib.sha256(raw).hexdigest();versions[doc]=version
            for i,paragraph in enumerate(re.split(r'\n\s*\n',text)):
                paragraph=paragraph.strip()
                if not paragraph:continue
                if len(paragraph)>6000:raise ValueError('PARAGRAPH_TOO_LARGE')
                ident=hashlib.sha256((doc+'\0'+version+'\0'+str(i)).encode()).hexdigest()
                chunks.append((ident,doc,version,i,paragraph,1))
        with self.connect() as db:
            db.execute('UPDATE chunks SET active=0')
            db.executemany('INSERT OR REPLACE INTO chunks VALUES (?,?,?,?,?,?)',chunks)
        return {'documents':len(files),'chunks':len(chunks),'versions':versions}
    def retrieve(self,message,limit=3):
        query=set(tokens(message))
        if not query:return []
        with self.connect() as db:rows=db.execute('SELECT * FROM chunks WHERE active=1 ORDER BY document,ordinal').fetchall()
        if not rows:return []
        counts=[Counter(tokens(row['text'])) for row in rows]
        average=max(1,sum(sum(c.values()) for c in counts)/len(counts));scores=[]
        df={term:sum(term in c for c in counts) for term in query}
        for row,c in zip(rows,counts):
            score=0.;length=sum(c.values())
            for term in query:
                freq=c[term]
                if freq:
                    idf=math.log(1+(len(rows)-df[term]+.5)/(df[term]+.5))
                    score+=idf*(freq*2.2)/(freq+1.2*(.25+.75*length/average))
            if score>0:scores.append((score,row))
        scores.sort(key=lambda x:(-x[0],x[1]['id']))
        return [{'id':r['id'],'document':r['document'],'version':r['version'],'paragraph':r['ordinal'],'excerpt':r['text'],'score':round(s,6)} for s,r in scores[:limit]]
    def citation(self,ident):
        with self.connect() as db:r=db.execute('SELECT * FROM chunks WHERE id=?',(ident,)).fetchone()
        if not r:raise HTTPException(404,detail={'code':'SOURCE_NOT_FOUND'})
        return {'id':r['id'],'document':r['document'],'version':r['version'],'paragraph':r['ordinal'],'excerpt':r['text'],'current':bool(r['active'])}


class Query(BaseModel):
    message:str=Field(min_length=1,max_length=2000)
    locale:Literal['zh-CN','en']='zh-CN'
    generate:bool=True
    request_id:str=Field(default_factory=lambda:uuid.uuid4().hex,pattern=r'^[a-f0-9]{32}$')


def create_app(data_root=None,generation_settings=None,provider=None,vision_origin=None):
    corpus=Corpus(data_root or os.environ.get('DOCS_DATA_ROOT','var/data'))
    settings=generation_settings or Settings.from_env()
    generator=Generator(corpus.root,settings,provider) if settings else None
    vision_origin=vision_origin or os.environ.get('VISION_API_ORIGIN')
    @asynccontextmanager
    async def lifespan(app):
        lock=(corpus.root/'worker.lock').open('a')
        try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:lock.close();raise RuntimeError('DATA_DIRECTORY_ALREADY_IN_USE')
        if generator:generator.ledger.recover()
        try:yield
        finally:lock.close()
    app=FastAPI(title='Documentation and experiment assistant',version='0.2.0',lifespan=lifespan)
    @app.get('/health')
    def health():return {'status':'ok','mode':'generated' if generator else 'retrieval_only','model_connected':bool(generator),'experiment_query_available':bool(vision_origin)}
    @app.get('/api/v1/budget')
    def budget():return generator.ledger.summary() if generator else {'monthly_limit_cny':0,'charged_or_reserved_cny':0,'model_connected':False}
    @app.post('/api/v1/chat')
    def chat(query:Query):
        citations=corpus.retrieve(query.message)
        if generator and query.generate and citations:
            try:
                response=generator.answer(query.message,query.locale,citations,query.request_id)
                return {**response,'tool_results':[],'experiment_query_available':bool(vision_origin)}
            except GenerationError as e:
                code=str(e);status=429 if code in ('BUDGET_EXHAUSTED','MODEL_BUSY') else 409 if code in ('REQUEST_ID_CONFLICT','REQUEST_PENDING_OR_UNCERTAIN') else 503
                raise HTTPException(status,detail={'code':code,'request_id':query.request_id}) from None
        if query.locale=='zh-CN':
            answer='以下是检索到的原文片段，本次未调用模型生成：' if citations else '当前文档未检索到相关依据。'
        else:answer='Retrieved source excerpts; no model generation was used for this request:' if citations else 'No matching evidence was found in the current documents.'
        return {'mode':'retrieval_only','answer':answer,'citations':citations,'usage':{'api_cost_cny':0,'model_calls':0},'tool_results':[],'experiment_query_available':bool(vision_origin),'request_id':query.request_id}
    @app.get('/api/v1/experiments/{ident}')
    def experiment(ident:str,authorization:str|None=Header(default=None)):
        try:return read_experiment(vision_origin,ident,authorization)
        except ExperimentError as e:raise HTTPException(e.status,detail={'code':e.code}) from None
    @app.get('/api/v1/sources/{ident}')
    def source(ident:str):return corpus.citation(ident)
    return app


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',default=os.environ.get('DOCS_DATA_ROOT','var/data'))
    sub=parser.add_subparsers(dest='command',required=True)
    ingest=sub.add_parser('ingest');ingest.add_argument('--source',required=True)
    serve=sub.add_parser('serve');serve.add_argument('--port',type=int,default=8002)
    args=parser.parse_args()
    if args.command=='ingest':print(json.dumps(Corpus(args.data_root).ingest(args.source),ensure_ascii=False))
    else:
        import uvicorn
        uvicorn.run(create_app(args.data_root),host='127.0.0.1',port=args.port)
if __name__=='__main__':main()
