"""Small deterministic retrieval evaluation; not a real model quality claim."""
import json,tempfile
from pathlib import Path
from docs_assistant.api import Corpus
cases=[('太阳模型登记样例','research.md','171'),('registered solar samples','research.md','protocol'),('高斯基线图片限制','vision.md','MiB'),('image limits Gaussian','vision.md','million'),('模型预算费用','assistant.md','25'),('monthly budget cost','assistant.md','25'),('任务失败重试','vision.md','retry_of'),('citation versions','assistant.md','SHA256'),('quantumwhalesxyz',None,None)]
with tempfile.TemporaryDirectory() as folder:
 c=Corpus(folder);c.ingest(Path(__file__).resolve().parents[1]/'examples/documents');results=[]
 for query,document,term in cases:
  hits=c.retrieve(query);ok=not hits if document is None else any(h['document']==document and term in h['excerpt'] for h in hits)
  results.append({'query':query,'expected_document':document,'pass':ok,'retrieved':[h['document'] for h in hits]})
 report={'scope':'local corpus retrieval only; no model called','passed':sum(r['pass'] for r in results),'total':len(results),'cases':results}
 print(json.dumps(report,ensure_ascii=False,indent=2))
 if report['passed']!=report['total']:raise SystemExit(1)
