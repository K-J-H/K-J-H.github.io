"""Versioned local snapshot; restore only into an absent directory."""
import argparse
import fcntl
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3


def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()

def backup(source,destination):
    source=Path(source).resolve();dest=Path(destination).resolve()
    if not source.is_dir() or dest.exists() or dest.is_relative_to(source):raise ValueError('INVALID_SNAPSHOT_DESTINATION')
    with (source/'worker.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        files=[]
        for p in source.rglob('*'):
            if p.is_symlink():raise ValueError('SYMLINK_REJECTED')
            if p.is_file() and p.name!='worker.lock' and not p.name.endswith(('-wal','-shm','-journal')):files.append(p)
        dest.mkdir(parents=True);checks={}
        for p in files:
            relative=p.relative_to(source);target=dest/'files'/relative;target.parent.mkdir(parents=True,exist_ok=True)
            if p.suffix=='.sqlite3':
                with sqlite3.connect(p) as a,sqlite3.connect(target) as b:a.backup(b)
            else:shutil.copyfile(p,target)
            checks[relative.as_posix()]=digest(target)
        (dest/'manifest.json').write_text(json.dumps({'schema_version':1,'files':checks},indent=2)+'\n')
    return {'files':len(checks),'status':'backed_up'}

def restore(source,destination):
    source=Path(source).resolve();dest=Path(destination).resolve()
    if dest.exists() or dest.is_relative_to(source):raise ValueError('RESTORE_REQUIRES_NEW_DIRECTORY')
    manifest=json.loads((source/'manifest.json').read_text())
    if manifest['schema_version']!=1 or not isinstance(manifest['files'],dict):raise ValueError('INVALID_MANIFEST')
    verified=[]
    for relative,sha in manifest['files'].items():
        name=Path(relative);file=source/'files'/name
        if name.is_absolute() or '..' in name.parts or file.is_symlink() or not file.resolve().is_relative_to(source/'files'):raise ValueError('UNSAFE_PATH')
        if digest(file)!=sha:raise ValueError('SNAPSHOT_CHECKSUM_MISMATCH')
        verified.append((file,name))
    dest.mkdir(parents=True)
    for file,name in verified:
        target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(file,target)
    return {'files':len(verified),'status':'restored'}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('action',choices=['backup','restore']);p.add_argument('source');p.add_argument('destination');a=p.parse_args()
    print(json.dumps((backup if a.action=='backup' else restore)(a.source,a.destination)))
