# Documentation and experiment assistant

[中文](README.md) · [Migration](docs/RUNBOOK.md)

Bilingual project questions with traceable source passages, optional grounded model generation, a persistent cost ledger and a read-only vision-task query. Retrieval-only is the default and needs no model account. Real external-provider acceptance is pending credentials; unit-test providers are never presented as production model results.

Reviewers can inspect lexical retrieval, immutable citation versions, transactional spending reservations, retry protection and tool authorization. This is an AI-assisted personal prototype, not an enterprise-scale knowledge base or autonomous agent.

## Install and verify from scratch

Tested target: Linux x86_64 with Python 3.12 and venv support. In this repository:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

For an offline installation, add `--no-index --find-links var/wheels` to the dependency installation command and supply the exact locked wheels. Recreate the environment; do not copy an old venv or use a sibling project's interpreter.

## Start without a key

```bash
.venv/bin/python -m docs_assistant.api --data-root var/data ingest --source examples/documents
VISION_API_ORIGIN=http://127.0.0.1:8001 .venv/bin/python -m docs_assistant.api --data-root var/data serve --port 8003
```

In another terminal:

```bash
curl -s http://127.0.0.1:8003/api/v1/chat -H 'Content-Type: application/json' -d '{"message":"Why are solar inputs restricted to registered samples?","locale":"en","generate":false}'
.venv/bin/python scripts/evaluate.py
```

Inspect `mode`, source versions and zero model calls. `/docs` describes the API. Source IDs remain readable through `/api/v1/sources/{id}` after document updates. Experiment queries need a running vision service and the original task's bearer token.

## Optional model setup

Use a compatible HTTPS Chat Completions provider supporting JSON output. Configure `LLM_KEY_FILE` (private local key file), `LLM_CHAT_URL` (full endpoint), `LLM_MODEL`, `LLM_INPUT_CNY_PER_MILLION`, `LLM_OUTPUT_CNY_PER_MILLION`, and optionally `LLM_MONTHLY_CNY` (default 25, maximum 30). Verify the provider's actual pricing and schema before enabling `generate=true`. Never place credentials in source or browser code. The application ledger covers this instance's calls, not unrelated spending on the provider account.

## Principles and limitations

**Versioned evidence.** Up to 100 Markdown files, each at most 256 KiB, are split on blank lines into paragraphs of at most 6,000 characters. SHA256 identifies document versions; document/version/ordinal identifies a citation. A transaction swaps active chunks while preserving old evidence. Symlink/path escapes are rejected.

**Lexical retrieval.** English alphanumeric words and Chinese bigrams are tokenized with stopword removal. Scores sum `log(1+(N-df+0.5)/(df+0.5))*f*2.2/(f+1.2*(0.25+0.75*L/avgL))`. Inverse document frequency reduces common-term weight and length normalization controls paragraph length. The top three positive scores become evidence. This is BM25-style lexical retrieval, not vector semantic search; accidental word overlap can still yield weak evidence.

**Grounded generation.** Only a configured, requested model with nonempty evidence is called. The prompt treats sources as untrusted quotations. JSON must include an answer and citation IDs drawn exclusively from retrieved chunks. Structural citation validity does not prove semantic faithfulness; real model evaluation and source inspection remain necessary.

**Cost reservation.** UTF-8 payload bytes plus a margin bound estimated input tokens; output is capped at 512 tokens. SQLite atomically reserves money before a call. Same ID/content returns cached results; changed content conflicts. Failures retain reservations and block automatic same-ID retries, avoiding uncertain double charges. After obtaining the exclusive application lock, restart converts abandoned reservations to uncertain. Usage settles actual cost; an over-reservation result blocks future calls for pricing review. Correct provider prices are essential; this is not an absolute external-billing guarantee.

**Read-only tool.** A user-triggered query calls only the server-configured vision origin. IDs and bearer syntax are validated, redirects blocked, returned fields allowlisted. Tokens are not placed in model prompts. No shell, file-writing or arbitrary-URL tool is exposed.

Nineteen service tests cover code contracts, budgets and failure paths. Real-provider answer quality, public abuse resistance and cross-host deployment are not yet verified. Local retrieval evaluation measures only this small published corpus.
