# 当前接口与状态契约

接口以运行服务的 /openapi.json 和契约测试为准。以下为 v0.2 本地原型的实际行为。

## 视觉

POST /api/v1/session 返回随机令牌。POST /api/v1/jobs 接收图片原始字节（不是multipart），仅 method_id=gaussian1，需 Bearer 和 Idempotency-Key。POST /api/v1/solar/jobs 接收登记 sample_id、crop=0、target=4..11；未知字段拒绝。

提交返回202与job_id/status；同owner和key同内容复用，不同内容409。GET /api/v1/jobs/{id} 返回状态/创建时间/retry_of/error/report；/result 下载PNG，/array 仅神经任务下载NPZ。无权限与不存在均404。POST /retry 仅failed/interrupted可创建关联新任务。

状态为queued → running → succeeded/failed；重启遗留running变interrupted。离线清理终态任务变expired，结果不再可下载。单worker、队列最大10、同数据目录独占锁。

## 文档助手

POST /api/v1/chat 字段message（1..2000字符）、locale（zh-CN/en）、generate布尔、request_id（32位小写hex，省略自动生成）。返回mode、answer、citations、usage、request_id；tool_results当前为空，不伪称模型自主工具调用。

无模型配置、generate=false或无依据时retrieval_only，不调用模型。可选generated结果必须包含合法引用。错误包含BUDGET_EXHAUSTED、MODEL_BUSY、REQUEST_ID_CONFLICT、REQUEST_PENDING_OR_UNCERTAIN和PROVIDER_UNAVAILABLE。

GET /api/v1/sources/{id}返回版本化原文，旧版本仍可查。GET /api/v1/budget返回当前UTC月记账/预留费用。GET /api/v1/experiments/{id}需要Bearer，只读转发到固定视觉origin，不接受用户URL或命令。

## 浏览器

静态前端只通过相对demo-api/docs-api访问；模型密钥不进入前端。会话令牌存sessionStorage；刷新/切语言可恢复图像任务。用户切换问答语言是新语义请求，仅显式提交才可能调用模型；不会因切语言自动花费。

UI中中文/英文解释错误；报告JSON保留技术字段名。CORS不是鉴权。当前服务绑定localhost，公网HTTPS/访问控制/限流仍需目标主机验收。
