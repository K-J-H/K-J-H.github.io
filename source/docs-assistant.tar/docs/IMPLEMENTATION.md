# 实现说明

Corpus版本化入库与BM25检索；Generator隔离提供商与费用Ledger；只读experiments工具固定origin。默认无模型可运行，不增加通用Agent框架。

系统性原理与从零命令见 [README](../README.md) / [English](../README.en.md)。遵循既有架构，不顺手重构无关模块；新增功能先补README、实现与测试约定再执行。破坏性数据操作或依赖大版本升级先确认。
