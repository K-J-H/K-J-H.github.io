from pathlib import Path
import importlib.util
import sqlite3
import pytest

spec=importlib.util.spec_from_file_location('snapshot',Path(__file__).resolve().parents[1]/'scripts/snapshot.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)

def test_snapshot_restore_and_corruption(tmp_path):
    source=tmp_path/'live';source.mkdir()
    with sqlite3.connect(source/'data.sqlite3') as db:
        db.execute('CREATE TABLE demo(value TEXT)');db.execute('INSERT INTO demo VALUES (?)',('persisted',))
    (source/'result.bin').write_bytes(b'actual-result')
    m.backup(source,tmp_path/'snapshot');m.restore(tmp_path/'snapshot',tmp_path/'recovered')
    with sqlite3.connect(tmp_path/'recovered/data.sqlite3') as db:assert db.execute('SELECT value FROM demo').fetchone()[0]=='persisted'
    assert (tmp_path/'recovered/result.bin').read_bytes()==b'actual-result'
    (tmp_path/'snapshot/files/result.bin').write_bytes(b'corrupt')
    with pytest.raises(ValueError,match='CHECKSUM'):m.restore(tmp_path/'snapshot',tmp_path/'bad')
    assert not (tmp_path/'bad').exists()
    with pytest.raises(ValueError):m.restore(tmp_path/'snapshot',source)

def test_path_traversal_rejected(tmp_path):
    import json
    source=tmp_path/'snapshot';source.mkdir();(source/'manifest.json').write_text(json.dumps({'schema_version':1,'files':{'../escape':'a'}}))
    with pytest.raises(ValueError,match='UNSAFE'):m.restore(source,tmp_path/'target')
    assert not (tmp_path/'target').exists()
