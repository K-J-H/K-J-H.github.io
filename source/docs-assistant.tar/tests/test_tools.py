import json,threading
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
import pytest
from docs_assistant.experiments import read_experiment,ExperimentError
from docs_assistant.generation import Ledger
import importlib.util
from pathlib import Path

@pytest.fixture
def upstream():
 class Handler(BaseHTTPRequestHandler):
  def do_GET(self):
   if self.headers.get('Authorization')!='Bearer '+'a'*40:self.send_response(404);self.end_headers();return
   self.send_response(200);self.end_headers();self.wfile.write(json.dumps({'job_id':self.path.rsplit('/',1)[1],'status':'succeeded','report':{'method':'test-fixture'},'error':None,'private_field':'must-not-leak'}).encode())
  def log_message(self,*args):pass
 server=ThreadingHTTPServer(('127.0.0.1',0),Handler);thread=threading.Thread(target=server.serve_forever);thread.start()
 try:yield 'http://127.0.0.1:'+str(server.server_port)
 finally:server.shutdown();thread.join();server.server_close()

def test_fixed_origin_read_only_http_and_allowlist(upstream):
 r=read_experiment(upstream,'b'*32,'Bearer '+'a'*40)
 assert r['read_only'] and r['status']=='succeeded' and 'private_field' not in r

def test_tool_cannot_read_another_sessions_record(upstream):
 with pytest.raises(ExperimentError) as e:read_experiment(upstream,'b'*32,'Bearer '+'c'*40)
 assert e.value.status==404

def test_tool_rejects_paths_tokens_and_unconfigured_origin():
 for origin,ident,token,status in [('http://127.0.0.1','../x','Bearer '+'a'*40,422),('http://127.0.0.1','b'*32,None,401),('http://user:pass@host','b'*32,'Bearer '+'a'*40,503)]:
  with pytest.raises(ExperimentError) as e:read_experiment(origin,ident,token)
  assert e.value.status==status

def test_budget_survives_snapshot_restore(tmp_path):
 spec=importlib.util.spec_from_file_location('snapshot',Path(__file__).resolve().parents[1]/'scripts/snapshot.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 source=tmp_path/'source';source.mkdir();ledger=Ledger(source,25);ledger.reserve('test-request','test-digest',1200)
 m.backup(source,tmp_path/'backup');m.restore(tmp_path/'backup',tmp_path/'restored')
 restored=Ledger(tmp_path/'restored',25);restored.recover();assert restored.summary()['charged_or_reserved_cny']==.0012
 with pytest.raises(Exception,match='UNCERTAIN'):restored.reserve('test-request','test-digest',1200)
