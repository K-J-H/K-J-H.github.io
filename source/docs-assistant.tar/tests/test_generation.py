import json,uuid
from concurrent.futures import ThreadPoolExecutor
import pytest
from fastapi.testclient import TestClient
from docs_assistant.generation import Settings,Ledger,Generator,GenerationError
from docs_assistant.api import create_app,Corpus

def settings(limit=25):return Settings('https://provider.invalid/chat/completions','test-model','test-only-key',1,2,limit)
def cite():return [{'id':'source-a','excerpt':'A verified test fact.','document':'a.md','version':'v1','paragraph':0}]
def response(ids=['source-a']):return {'choices':[{'message':{'content':json.dumps({'answer':'A verified test fact.','citation_ids':ids})}}],'usage':{'prompt_tokens':100,'completion_tokens':20}}

def test_actual_usage_idempotency_and_restart(tmp_path):
    calls=[]
    g=Generator(tmp_path,settings(),lambda p:(calls.append(p) or response()));ident=uuid.uuid4().hex
    first=g.answer('fact','en',cite(),ident);assert first['usage']['api_cost_cny']==0.00014
    second=Generator(tmp_path,settings(),lambda _:pytest.fail('must not call again')).answer('fact','en',cite(),ident)
    assert second['cached'] and second['usage']['model_calls']==0 and len(calls)==1
    with pytest.raises(GenerationError,match='CONFLICT'):g.answer('different','en',cite(),ident)

def test_budget_reservation_is_atomic(tmp_path):
    ledger=Ledger(tmp_path,.01)
    def attempt(i):
        try:ledger.reserve(str(i),'same',6000);return True
        except GenerationError:return False
    with ThreadPoolExecutor(max_workers=4) as pool:assert sum(pool.map(attempt,range(4)))==1
    assert Ledger(tmp_path,.01).summary()['charged_or_reserved_cny']==.006

def test_uncertain_call_is_not_repeated_and_fake_citation_rejected(tmp_path):
    g=Generator(tmp_path,settings(),lambda _:response(['fabricated']))
    ident=uuid.uuid4().hex
    with pytest.raises(GenerationError,match='CITATIONS'):g.answer('fact','en',cite(),ident)
    with pytest.raises(GenerationError,match='UNCERTAIN'):g.answer('fact','en',cite(),ident)
    assert g.ledger.summary()['charged_or_reserved_cny']>0

def test_excess_usage_blocks_future_calls(tmp_path):
    result=response();result['usage']['prompt_tokens']=10_000_000
    g=Generator(tmp_path,settings(),lambda _:result)
    with pytest.raises(GenerationError,match='PRICING'):g.answer('fact','en',cite(),uuid.uuid4().hex)
    with pytest.raises(GenerationError,match='PRICING'):g.answer('fact','en',cite(),uuid.uuid4().hex)

def test_api_no_evidence_costs_nothing_and_valid_generation(tmp_path):
    src=tmp_path/'src';src.mkdir();(src/'a.md').write_text('Gaussian baseline is not a neural model.')
    data=tmp_path/'data';Corpus(data).ingest(src);calls=[]
    def provider(payload):
        calls.append(payload); evidence=json.loads(payload['messages'][1]['content'])['evidence']
        return response([evidence[0]['id']])
    with TestClient(create_app(data,settings(),provider)) as c:
        r=c.post('/api/v1/chat',json={'message':'quantumwhale','locale':'en'}).json();assert r['mode']=='retrieval_only' and not calls
        r=c.post('/api/v1/chat',json={'message':'Gaussian baseline','locale':'en'}).json();assert r['mode']=='generated' and r['citations'] and len(calls)==1
        assert c.get('/api/v1/budget').json()['requests']==1

def test_limits_and_read_only_tool_unavailable(tmp_path):
    with pytest.raises(GenerationError):settings(31).validate()
    with TestClient(create_app(tmp_path)) as c:
        assert c.get('/api/v1/experiments/'+'a'*32,headers={'Authorization':'Bearer '+'b'*40}).status_code==503


def test_crash_recovery_keeps_reservation_without_blocking_slot(tmp_path):
    ledger=Ledger(tmp_path,25)
    ledger.reserve('interrupted','digest',1000)
    ledger.recover()
    assert ledger.summary()['charged_or_reserved_cny']==.001
    with pytest.raises(GenerationError,match='UNCERTAIN'):ledger.reserve('interrupted','digest',1000)
    assert ledger.reserve('new','digest',1000) is None


def test_provider_failure_keeps_budget_and_never_leaks_secret(tmp_path):
    def fail(_):raise RuntimeError('test-only-key')
    g=Generator(tmp_path,settings(),fail)
    with pytest.raises(GenerationError,match='^PROVIDER_UNAVAILABLE$'):g.answer('fact','en',cite(),uuid.uuid4().hex)
    assert g.ledger.summary()['charged_or_reserved_cny']>0


def test_missing_usage_is_charged_conservatively(tmp_path):
    result=response();result.pop('usage')
    g=Generator(tmp_path,settings(),lambda _:result)
    r=g.answer('fact','en',cite(),uuid.uuid4().hex)
    assert r['usage']['api_cost_cny']>0
    assert g.ledger.summary()['charged_or_reserved_cny']==r['usage']['api_cost_cny']
