# 引用与费用 / Citations and cost

引用版本由文档 SHA256 和段落编号确定。更新文档保留旧版本段落，历史来源仍可核查。中文双字与英文词通过 BM25 风格词法检索排名，当前没有向量检索。

Citation versions use document SHA256 and paragraph ordinals. Updating documents preserves old passages for historical verification. Chinese bigrams and English words feed BM25-style lexical ranking; no vector retrieval is implemented.

模型月预算默认 25 元、配置最多 30 元；先原子预留，后按返回用量结算。未知或超时请求保留预算且不自动重复调用。同一 request_id 可返回缓存。价格需要核实，应用不能限制其他客户端的账户消费。

The model budget defaults to CNY 25 per month and allows at most CNY 30 in configuration. Calls reserve cost atomically and settle reported usage. Uncertain requests keep their reservation and are not automatically repeated; the same request_id can return cached results. Prices must be verified; the app cannot control other clients' account spending.

实验工具只读查询配置好的视觉服务，使用当前会话令牌，不执行命令、不写文件、不向任意地址发送请求。令牌不进入模型上下文。

The experiment tool only reads from the configured vision service using the current session token. It cannot execute commands, write files or call arbitrary destinations. Tokens are not sent to the model context.
