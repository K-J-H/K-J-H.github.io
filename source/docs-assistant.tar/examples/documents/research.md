# 太阳模型 / Solar model

太阳模型只接受登记样例，因为科学输入协议要求 SDO/AIA 171 Å、DN/s 单位、128×128 上下文、掩码与时间间隔；普通 RGB 照片不满足协议。输入 SHA256、固定权重和协议均在推理前核对。

The solar model accepts only registered samples because the scientific input protocol requires SDO/AIA 171 Å observations, DN/s units, a 128×128 context, masks and cadence. Ordinary RGB photos do not meet this protocol. Input SHA256, fixed weights and protocol are verified before inference.

SHINE 是第三方 MIT 架构，不是本项目原创网络。CPU 推理除以 1000 归一化，模型后乘以 1000 恢复单位，取中心 64×64。研究稿件仍在修改，公开演示不是新保留测试集。

SHINE is third-party MIT architecture, not an original network invented for this project. CPU inference divides by 1000, restores units afterward and extracts the central 64×64 crop. The manuscript is in revision; the demo is not a new holdout.

差异 RMSE（difference RMSE）只量化输出与原观测的变化，没有干净真值时不能称为去噪准确率或真实 PSNR。当前已知增量窄探针没有证明时空模型优于高斯对照。

Difference RMSE measures change between output and observation. Without clean ground truth it is not denoising accuracy or a clean-reference PSNR. The existing narrow known-increment probe did not show temporal models outperforming the Gaussian control.
