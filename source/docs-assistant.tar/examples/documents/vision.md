# 图像任务 / Image tasks

普通 PNG/JPEG 图片上传执行高斯平滑传统基线（Gaussian baseline），不是神经网络去噪。限制为 4 MiB、100 万像素、单张静态图片。像素变化不能解释为干净真值准确率。

Ordinary PNG/JPEG uploads run a Gaussian baseline, not neural denoising. Limits are 4 MiB, one million pixels and a single static image. Pixel change is not clean-reference accuracy.

任务幂等性由访问者和 Idempotency-Key 共同决定。同键同图返回原任务；同键不同内容冲突。Bearer 令牌用于查询和下载自己的任务，不可公开共享。

Idempotency is scoped to the owner and Idempotency-Key. The same key and image return the original job; changed content conflicts. Keep the Bearer token to query and download your own jobs.

任务失败重试创建新的 retry_of 子任务，保留原始失败。服务重启将 running 标为 interrupted，queued 继续。离线保留策略默认预览，只处理超期终态任务，必须停止服务后执行。

Retry creates a new child task linked by retry_of and preserves the original failure. Restart marks running tasks interrupted and continues queued tasks. Offline retention defaults to dry run and touches only expired terminal tasks after the service stops.
