"""Real HTTP client: synthetic fixture or user image, no stored credentials."""
import argparse,hashlib,io,json,time,urllib.request
from pathlib import Path
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('--url',default='http://127.0.0.1:8001');p.add_argument('--image',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
if a.output.exists():raise SystemExit('OUTPUT_MUST_NOT_EXIST')
if a.image:raw=a.image.read_bytes()
else:
 image=Image.new('RGB',(96,64),'navy');ImageDraw.Draw(image).rectangle((25,13,53,36),fill='gold');b=io.BytesIO();image.save(b,format='PNG');raw=b.getvalue()
def request(path,data=None,headers={}):
 with urllib.request.urlopen(urllib.request.Request(a.url+path,data=data,headers=headers),timeout=30) as r:return r.read()
token=json.loads(request('/api/v1/session',b''))['token'];headers={'Authorization':'Bearer '+token,'Idempotency-Key':hashlib.sha256(raw).hexdigest(),'Content-Type':'application/octet-stream'}
job=json.loads(request('/api/v1/jobs',raw,headers));deadline=time.monotonic()+60
while job['status'] in ('queued','running') and time.monotonic()<deadline:
 time.sleep(.1);job=json.loads(request('/api/v1/jobs/'+job['job_id'],headers=headers))
if job['status']!='succeeded':raise SystemExit('TASK_NOT_SUCCESSFUL')
result=request('/api/v1/jobs/'+job['job_id']+'/result',headers=headers)
assert hashlib.sha256(result).hexdigest()==job['report']['result_sha256']
a.output.mkdir(parents=True);(a.output/'result.png').write_bytes(result);(a.output/'report.json').write_text(json.dumps(job,indent=2)+'\n');print(json.dumps({'status':'PASS','job_id':job['job_id'],'hash_verified':True}))
