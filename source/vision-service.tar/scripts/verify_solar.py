"""Real-weight service integration, fails if assets or optional dependencies are missing."""
import argparse,hashlib,io,json,time
from pathlib import Path
import numpy as np
from fastapi.testclient import TestClient
from vision_service.api import create_app
from vision_service import solar
from solar_research.cli import load_observation
from solar_research.neural import SpatialModel

p=argparse.ArgumentParser();p.add_argument('--assets',type=Path,required=True);p.add_argument('--data-root',type=Path,required=True);p.add_argument('--url');a=p.parse_args()
raw,keep,_=load_observation(a.assets/'2024-03-01.npz',solar.SHA,0,7)
y=SpatialModel(a.assets/'checkpoint.pt',a.assets/'protocol.json').predict(raw)
if a.url:
 import httpx
 client=httpx.Client(base_url=a.url,timeout=30)
else:client=TestClient(create_app(a.data_root,a.assets))
with client as c:
 assert c.get('/api/v1/solar/capability').json()['available']
 token=c.post('/api/v1/session').json()['token'];h={'Authorization':'Bearer '+token,'Idempotency-Key':'solar-'+str(time.time_ns())}
 payload={'sample_id':solar.SAMPLE,'target':7}
 r=c.post('/api/v1/solar/jobs',headers=h,json=payload);assert r.status_code==202,r.text
 ident=r.json()['job_id'];base='/api/v1/jobs/'+ident
 assert c.post('/api/v1/solar/jobs',headers=h,json=payload).json()['job_id']==ident
 assert c.post('/api/v1/solar/jobs',headers=h,json={**payload,'target':6}).status_code==409
 until=time.monotonic()+30
 while time.monotonic()<until:
  job=c.get(base,headers=h).json()
  if job['status'] in ('succeeded','failed','interrupted'):break
  time.sleep(.03)
 assert job['status']=='succeeded',job
 assert job['report']['neural_model'] and job['report']['checkpoint_sha256']==solar.MODEL_SHA
 data=c.get(base+'/array',headers=h);assert data.status_code==200
 with np.load(io.BytesIO(data.content),allow_pickle=False) as d:
  np.testing.assert_array_equal(d['shine_dn_s'],y);np.testing.assert_array_equal(d['valid'],keep)
 preview=c.get(base+'/result',headers=h);assert preview.status_code==200
 assert hashlib.sha256(preview.content).hexdigest()==job['report']['preview_sha256']
 assert hashlib.sha256(data.content).hexdigest()==job['report']['array_sha256']
 other={'Authorization':'Bearer '+'other'*10}
 for suffix in ('','/array','/result'):assert c.get(base+suffix,headers=other).status_code==404
 if a.url:assert c.get(base+'/array',headers=h).content==data.content
if not a.url:
 with TestClient(create_app(a.data_root,a.assets)) as c:
  assert c.get(base,headers=h).json()['status']=='succeeded'
  assert c.get(base+'/array',headers=h).content==data.content
print(json.dumps({'status':'PASS','job_id':ident,'array_sha256':job['report']['array_sha256'],'preview_sha256':job['report']['preview_sha256'],'direct_equal':True,'restart_checked':not bool(a.url),'transport':'HTTP' if a.url else 'TestClient','data_root':str(a.data_root)}))
