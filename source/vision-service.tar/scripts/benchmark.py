"""Small real localhost latency probe, not a production load claim."""
import argparse,io,json,time,urllib.request,statistics
from PIL import Image,ImageDraw
p=argparse.ArgumentParser();p.add_argument('--url',default='http://127.0.0.1:8001');p.add_argument('--count',type=int,default=10);a=p.parse_args()
if not 1<=a.count<=20:raise SystemExit('COUNT_1_TO_20')
def call(path,data=None,headers={}):
 with urllib.request.urlopen(urllib.request.Request(a.url+path,data=data,headers=headers),timeout=30) as r:return json.load(r)
token=call('/api/v1/session',b'')['token'];latencies=[];ids=[]
for i in range(a.count):
 image=Image.new('RGB',(256,256),(10+i,20,30));ImageDraw.Draw(image).rectangle((20,20,160,160),fill=(200,180,10));b=io.BytesIO();image.save(b,format='PNG')
 start=time.perf_counter();headers={'Authorization':'Bearer '+token,'Idempotency-Key':'probe-'+str(i)};job=call('/api/v1/jobs',b.getvalue(),headers)
 while job['status'] in ('queued','running') and time.perf_counter()-start<30:
  time.sleep(.02);job=call('/api/v1/jobs/'+job['job_id'],headers=headers)
 if job['status']!='succeeded':raise RuntimeError('TASK_FAILED')
 latencies.append(time.perf_counter()-start);ids.append(job['job_id'])
print(json.dumps({'scope':'sequential localhost synthetic 256x256 PNG Gaussian tasks; not neural or public load','count':a.count,'median_seconds':statistics.median(latencies),'max_seconds':max(latencies),'all_succeeded':True,'job_ids':ids}))
