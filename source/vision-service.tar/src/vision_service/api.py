"""Local single-worker image service with an optional registered solar model."""
import argparse
from contextlib import asynccontextmanager
import fcntl
import hashlib
import io
import json
import os
from pathlib import Path
import secrets
import sqlite3
import threading
import time
import uuid
import warnings
from . import solar
from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.responses import FileResponse
from PIL import Image, ImageFilter, ImageStat, ImageChops, UnidentifiedImageError

MAX_BYTES=4*1024*1024
MAX_PIXELS=1024*1024

def error(status,code): return HTTPException(status,detail={'code':code})

def owner(authorization):
    if not authorization or not authorization.startswith('Bearer '): raise error(401,'UNAUTHORIZED')
    token=authorization[7:]
    if not 32<=len(token)<=256: raise error(401,'UNAUTHORIZED')
    return hashlib.sha256(token.encode()).hexdigest()


def decode_image(raw):
    if not raw or len(raw)>MAX_BYTES: raise error(413,'PAYLOAD_TOO_LARGE')
    try:
        with warnings.catch_warnings():
            warnings.simplefilter('error',Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(raw)) as im:
                if im.format not in ('PNG','JPEG') or getattr(im,'n_frames',1)!=1: raise error(422,'UNSUPPORTED_FORMAT')
                if im.width*im.height>MAX_PIXELS: raise error(413,'PIXELS_TOO_LARGE')
                im.load()
                return im.convert('RGB')
    except (UnidentifiedImageError,OSError,ValueError,Image.DecompressionBombError,Image.DecompressionBombWarning):
        raise error(422,'INVALID_IMAGE')


class Store:
    def __init__(self,root,solar_root=None):
        self.solar_root=solar_root
        self.root=Path(root).resolve();self.root.mkdir(parents=True,exist_ok=True)
        self.db=self.root/'jobs.sqlite3'
        self.submit_lock=threading.Lock();self.stop=threading.Event()
        with self.connect() as db:
            db.execute('CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,owner TEXT NOT NULL,idem TEXT NOT NULL,digest TEXT NOT NULL,status TEXT NOT NULL,created REAL NOT NULL,report TEXT,error TEXT,UNIQUE(owner,idem))')
            db.execute('CREATE TABLE IF NOT EXISTS retry_links(child TEXT PRIMARY KEY,parent TEXT NOT NULL)')
    def connect(self):
        db=sqlite3.connect(self.db,timeout=10);db.row_factory=sqlite3.Row;return db
    def start(self):
        self.lockfile=(self.root/'worker.lock').open('a')
        try:fcntl.flock(self.lockfile,fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.lockfile.close();raise RuntimeError('DATA_DIRECTORY_ALREADY_IN_USE')
        with self.connect() as db:db.execute("UPDATE jobs SET status='interrupted',error='PROCESS_INTERRUPTED' WHERE status='running'")
        self.thread=threading.Thread(target=self.loop,daemon=True);self.thread.start()
    def close(self):
        self.stop.set();self.thread.join();self.lockfile.close()
    def submit(self,principal,key,raw):
        digest=hashlib.sha256(raw).hexdigest()
        with self.submit_lock,self.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            old=db.execute('SELECT * FROM jobs WHERE owner=? AND idem=?',(principal,key)).fetchone()
            if old:
                if old['digest']!=digest:raise error(409,'IDEMPOTENCY_CONFLICT')
                return dict(old)
            if db.execute("SELECT count(*) FROM jobs WHERE status IN ('queued','running')").fetchone()[0]>=10:raise error(429,'QUEUE_FULL')
            ident=uuid.uuid4().hex
            folder=self.root/ident;folder.mkdir()
            (folder/'input.bin').write_bytes(raw)
            db.execute('INSERT INTO jobs(id,owner,idem,digest,status,created) VALUES (?,?,?,?,?,?)',(ident,principal,key,digest,'queued',time.time()))
            return dict(db.execute('SELECT * FROM jobs WHERE id=?',(ident,)).fetchone())
    def get(self,ident,principal):
        with self.connect() as db:row=db.execute('SELECT * FROM jobs WHERE id=? AND owner=?',(ident,principal)).fetchone()
        if not row:raise error(404,'NOT_FOUND_OR_FORBIDDEN')
        result=dict(row)
        with self.connect() as db:
            link=db.execute('SELECT parent FROM retry_links WHERE child=?',(ident,)).fetchone()
        result['retry_of']=link['parent'] if link else None
        return result
    def retry(self,ident,principal,key):
        old=self.get(ident,principal)
        if old['status'] not in ('failed','interrupted'):raise error(409,'TASK_NOT_RETRYABLE')
        try:raw=(self.root/old['id']/'input.bin').read_bytes()
        except OSError:raise error(410,'INPUT_UNAVAILABLE')
        if hashlib.sha256(raw).hexdigest()!=old['digest']:raise error(409,'INPUT_CHECKSUM_MISMATCH')
        row=self.submit(principal,'retry:'+ident+':'+key,raw)
        with self.connect() as db:db.execute('INSERT OR IGNORE INTO retry_links(child,parent) VALUES (?,?)',(row['id'],ident))
        return self.get(row['id'],principal)
    def loop(self):
        while not self.stop.is_set():
            with self.connect() as db:
                db.execute('BEGIN IMMEDIATE')
                job=db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY created LIMIT 1").fetchone()
                if job:db.execute("UPDATE jobs SET status='running' WHERE id=?",(job['id'],))
            if not job:self.stop.wait(.05);continue
            try:
                folder=self.root/job['id'];raw=(folder/'input.bin').read_bytes()
                if hashlib.sha256(raw).hexdigest()!=job['digest']:raise ValueError('INPUT_CHECKSUM_MISMATCH')
                if raw.startswith(solar.PREFIX):
                    report=solar.process(raw,self.solar_root,folder)
                else:
                    started=time.perf_counter();image=decode_image(raw);result=image.filter(ImageFilter.GaussianBlur(radius=1))
                    temp=folder/'result.tmp';result.save(temp,format='PNG');temp.replace(folder/'result.png')
                    report={'method':'pillow_gaussian_radius1','method_kind':'classical_baseline','neural_model':False,
                        'width':image.width,'height':image.height,'input_sha256':job['digest'],
                        'result_sha256':hashlib.sha256((folder/'result.png').read_bytes()).hexdigest(),
                        'mean_absolute_change_rgb':ImageStat.Stat(ImageChops.difference(image,result)).mean,
                        'elapsed_seconds':time.perf_counter()-started,'limitation':'Pixel change is not denoising accuracy; no clean reference.'}
                (folder/'report.json').write_text(json.dumps(report,indent=2))
                with self.connect() as db:db.execute("UPDATE jobs SET status='succeeded',report=? WHERE id=?",(json.dumps(report),job['id']))
            except Exception:
                with self.connect() as db:db.execute("UPDATE jobs SET status='failed',error='PROCESSING_FAILED' WHERE id=?",(job['id'],))


def public(job):
    return {'job_id':job['id'],'status':job['status'],'created':job['created'],'retry_of':job.get('retry_of'),'error':job['error'],'report':json.loads(job['report']) if job['report'] else None}


def create_app(data_root=None,solar_root=None):
    solar_root=solar_root or os.environ.get('VISION_SOLAR_ROOT')
    root=Path(data_root or os.environ.get('VISION_DATA_ROOT','var/data'))
    @asynccontextmanager
    async def lifespan(app):
        app.state.store=Store(root,solar_root);app.state.store.start()
        try:yield
        finally:app.state.store.close()
    app=FastAPI(title='Vision processing service',version='0.2.0',lifespan=lifespan)
    @app.get('/health')
    def health():
        enabled=capability()['available']
        return {'status':'ok','mode':'baseline_and_registered_solar' if enabled else 'classical_baseline','neural_model':enabled}
    @app.get('/api/v1/solar/capability')
    def capability():
        try:solar.check_assets(solar_root)
        except (ValueError,OSError):return {'available':False,'sample_id':solar.SAMPLE}
        return {'available':True,'sample_id':solar.SAMPLE,'crop':0,'targets':list(range(4,12)),'device':'cpu'}
    @app.post('/api/v1/solar/jobs',status_code=202)
    async def submit_solar(request:Request,authorization:str|None=Header(default=None),idempotency_key:str|None=Header(default=None)):
        principal=owner(authorization)
        if not idempotency_key or not 1<=len(idempotency_key)<=128:raise error(422,'IDEMPOTENCY_KEY_REQUIRED')
        body=bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body)>1024:raise error(413,'PAYLOAD_TOO_LARGE')
        try:raw=solar.encode(json.loads(body))
        except (ValueError,TypeError):raise error(422,'INVALID_SOLAR_PARAMETERS')
        try:solar.check_assets(solar_root)
        except (ValueError,OSError):raise error(503,'SOLAR_UNAVAILABLE')
        return public(app.state.store.submit(principal,idempotency_key,raw))
    @app.get('/api/v1/jobs/{ident}/array')
    def array(ident:str,authorization:str|None=Header(default=None)):
        job=app.state.store.get(ident,owner(authorization))
        if job['status']!='succeeded':raise error(409,'RESULT_NOT_READY')
        if not json.loads(job['report']).get('neural_model'):raise error(404,'NO_SCIENTIFIC_ARRAY')
        return FileResponse(app.state.store.root/job['id']/'scientific/result.npz',media_type='application/octet-stream',filename='result.npz')
    @app.post('/api/v1/session')
    def session():return {'token':secrets.token_urlsafe(32),'note':'Keep this bearer token to access your local demo jobs.'}
    @app.post('/api/v1/jobs',status_code=202)
    async def submit(request:Request,method_id:str='gaussian1',authorization:str|None=Header(default=None),idempotency_key:str|None=Header(default=None)):
        principal=owner(authorization)
        if method_id!='gaussian1':raise error(422,'UNSUPPORTED_METHOD')
        if not idempotency_key or not 1<=len(idempotency_key)<=128:raise error(422,'IDEMPOTENCY_KEY_REQUIRED')
        body=bytearray()
        async for chunk in request.stream():
            body.extend(chunk)
            if len(body)>MAX_BYTES:raise error(413,'PAYLOAD_TOO_LARGE')
        raw=bytes(body);decode_image(raw)
        return public(app.state.store.submit(principal,idempotency_key,raw))
    @app.post('/api/v1/jobs/{ident}/retry',status_code=202)
    def retry(ident:str,authorization:str|None=Header(default=None),idempotency_key:str|None=Header(default=None)):
        principal=owner(authorization)
        if not idempotency_key or not 1<=len(idempotency_key)<=128:raise error(422,'IDEMPOTENCY_KEY_REQUIRED')
        return public(app.state.store.retry(ident,principal,idempotency_key))
    @app.get('/api/v1/jobs/{ident}')
    def get(ident:str,authorization:str|None=Header(default=None)):
        return public(app.state.store.get(ident,owner(authorization)))
    @app.get('/api/v1/jobs/{ident}/result')
    def result(ident:str,authorization:str|None=Header(default=None)):
        job=app.state.store.get(ident,owner(authorization))
        if job['status']!='succeeded':raise error(409,'RESULT_NOT_READY')
        return FileResponse(app.state.store.root/job['id']/'result.png',media_type='image/png',filename='result.png')
    return app


def main():
    import uvicorn
    parser=argparse.ArgumentParser();parser.add_argument('--data-root',default=os.environ.get('VISION_DATA_ROOT','var/data'));parser.add_argument('--port',type=int,default=8001)
    parser.add_argument('--solar-root',default=os.environ.get('VISION_SOLAR_ROOT'))
    args=parser.parse_args();uvicorn.run(create_app(args.data_root,args.solar_root),host='127.0.0.1',port=args.port)
if __name__=='__main__':main()
