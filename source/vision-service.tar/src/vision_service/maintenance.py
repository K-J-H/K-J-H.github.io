"""Opt-in retention maintenance. Dry-run by default; never operates on active tasks."""
import argparse,fcntl,json,re,shutil,time
from pathlib import Path
from .api import Store

def prune(root,days=30,apply=False):
    if days<1:raise ValueError('RETENTION_AT_LEAST_ONE_DAY')
    root=Path(root).resolve()
    if not (root/'jobs.sqlite3').is_file():raise ValueError('NOT_A_VISION_DATA_DIRECTORY')
    store=Store(root)
    with (root/'worker.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        with store.connect() as db:
            db.execute('BEGIN IMMEDIATE')
            rows=db.execute("SELECT id FROM jobs WHERE status IN ('succeeded','failed','interrupted','expired') AND created<?",(time.time()-days*86400,)).fetchall()
            targets=[]
            for row in rows:
                ident=row['id'];folder=root/ident
                if not re.fullmatch('[a-f0-9]{32}',ident) or folder.is_symlink() or folder.resolve().parent!=root:raise ValueError('UNSAFE_JOB_PATH')
                targets.append(folder)
            if apply:
                # Mark expired first: a later filesystem failure cannot expose an incomplete result.
                db.executemany("UPDATE jobs SET status='expired',error='RETENTION_EXPIRED',report=NULL WHERE id=?",[(f.name,) for f in targets]);db.commit()
                for folder in targets:
                    if folder.exists():shutil.rmtree(folder)
            return {'apply':apply,'retention_days':days,'job_ids':[f.name for f in targets],'count':len(targets)}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data-root',required=True);p.add_argument('--days',type=int,default=30);p.add_argument('--apply',action='store_true');a=p.parse_args();print(json.dumps(prune(a.data_root,a.days,a.apply)))
if __name__=='__main__':main()
