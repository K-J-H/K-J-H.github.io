"""Adapter for a registered scientific sample, never arbitrary RGB input."""
import hashlib
import importlib.util
import json
from pathlib import Path

PREFIX=b'SOLAR_JOB_V1\n'
SAMPLE='aia171-dev-20240301'
SHA='ed1400d58a77f1bb3d1675baba01b82b34620d0845a0d7935c30d7a90758c6c6'
MODEL_SHA='a22f2eddf968231c8c40887a4bf522406ac3817e7186a13c3fe5843ba242d4f5'
PROTOCOL_SHA='3a330c901e03aadb0bb237c847c0e1808e8c7e15a53b370ff0a3d9d5d660a9ef'


def validate(body):
    if not isinstance(body,dict) or set(body)-{'sample_id','crop','target'}:
        raise ValueError('INVALID_SOLAR_PARAMETERS')
    if body.get('sample_id')!=SAMPLE or type(body.get('crop',0)) is not int or body.get('crop',0)!=0:
        raise ValueError('UNKNOWN_SAMPLE_OR_CROP')
    target=body.get('target',7)
    if type(target) is not int or not 4<=target<12:
        raise ValueError('INVALID_TARGET')
    return {'sample_id':SAMPLE,'crop':0,'target':target,'sample_sha256':SHA,'checkpoint_sha256':MODEL_SHA,'protocol_sha256':PROTOCOL_SHA}


def encode(body):
    return PREFIX+json.dumps(validate(body),sort_keys=True,separators=(',',':')).encode()


def check_assets(root):
    if root is None or importlib.util.find_spec('solar_research') is None or importlib.util.find_spec('torch') is None:
        raise ValueError('SOLAR_NOT_CONFIGURED')
    root=Path(root)
    for name,expected in [('2024-03-01.npz',SHA),('checkpoint.pt',MODEL_SHA),('protocol.json',PROTOCOL_SHA)]:
        with (root/name).open('rb') as stream:
            if hashlib.file_digest(stream,'sha256').hexdigest()!=expected:
                raise ValueError('SOLAR_ASSET_CHECKSUM_MISMATCH')


def process(raw,root,folder):
    check_assets(root)
    params=json.loads(raw[len(PREFIX):])
    expected=validate({k:params[k] for k in ('sample_id','crop','target')})
    if params!=expected:raise ValueError('SOLAR_VERSION_MISMATCH')
    from solar_research.neural import run
    root=Path(root);folder=Path(folder)
    report=run(root/'2024-03-01.npz',SHA,root/'checkpoint.pt',root/'protocol.json',folder/'scientific',params['crop'],params['target'])
    image=(folder/'scientific/comparison.png').read_bytes()
    temp=folder/'result.tmp';temp.write_bytes(image);temp.replace(folder/'result.png')
    report.update(neural_model=True,sample_id=SAMPLE,preview_sha256=hashlib.sha256(image).hexdigest(),array_sha256=report['result_sha256'])
    return report
