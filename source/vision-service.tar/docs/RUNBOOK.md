# 运行、备份与迁移 / Runbook

以 [README](../README.md) / [English](../README.en.md) 的安装与启动命令为准。支持 Linux x86_64 / Python 3.12，每个项目自己的 .venv、锁文件和 var 数据。运行不能借用兄弟项目的环境。

## 从一台机器迁移到另一台

1. 导出本项目源码和锁文件，单独复制有权使用的模型/数据以及必要离线 wheels。密钥单独配置，不进入 Git。
2. 在原机正常停止**本项目**服务，等 worker 结束；不要终止科研发行版。对数据制作一致性快照：

```bash
.venv/bin/python scripts/snapshot.py backup var/data var/backup-new
```

3. 在目标机按 README 新建虚拟环境并安装锁依赖，不拷贝旧 venv。将快照放到本项目目录，恢复到新目录：

```bash
.venv/bin/python scripts/snapshot.py restore var/backup-new var/restored-new
```

4. 用 --data-root var/restored-new 和新端口启动，验证旧记录可查、新请求可完成、哈希一致；检查日志再切换正式入口。
5. 保留原数据以便回退。不要覆盖旧库或跳过快照哈希检查。

快照工具使用独占锁和 SQLite backup API，并核对文件哈希；正在运行的服务会阻止备份。它不是在线多机复制工具。数据目录实际使用 var/demo-data 时，相应替换上例 var/data。

## 独立性与边界

同机新目录/新 venv 验收通过，不等于跨机器或容器已验收。同一系统用户下的 venv 隔离依赖，不构成文件访问安全边界。真正公网部署还需要单独用户/容器、反向代理、HTTPS、访问控制和资源上限。

太阳可选路径另需 var/solar、var/solar-wheels 和 solar-package.json 对应的精确 wheel。原图和结果有保留周期，先用 maintenance 的默认 dry run 核对，实际删除需备份并明确确认。
