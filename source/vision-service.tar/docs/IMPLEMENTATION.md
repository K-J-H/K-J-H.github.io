# 实现说明

FastAPI路由 → Store的SQLite事务/幂等/队列 → 单worker → 普通基线或solar适配。maintenance.py默认dry run，显式apply才删除超期终态文件；snapshot.py在服务停止后备份恢复。

系统性原理与从零命令见 [README](../README.md) / [English](../README.en.md)。遵循既有架构，不顺手重构无关模块；新增功能先补README、实现与测试约定再执行。破坏性数据操作或依赖大版本升级先确认。
