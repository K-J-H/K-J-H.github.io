# 视觉推理与异步任务服务

[English](README.en.md) · [运行与迁移](docs/RUNBOOK.md) · [测试说明](docs/TESTING.md)

**把视觉实验包装成别人可以提交、追踪、复算和下载的工具。** 服务有两个明确分开的入口：普通 PNG/JPEG 执行高斯基线；登记太阳样例执行真实 SHINE CPU 模型。普通照片不会被偷偷送给太阳模型。

## 30 秒了解工程能力

FastAPI 接口、SQLite 持久任务、单执行器队列、访问令牌、幂等提交、失败重试、报告与结果下载。模型版本/输入哈希随结果保存；重启将运行中的任务标为 interrupted，避免无法解释的自动重跑。12 项服务测试已通过，另有真实权重直接调用/服务输出逐元素一致与真实 HTTP 验收。

这是个人工程原型，AI 辅助开发；没有企业生产流量或商用 SLA 的声明。太阳架构和研究包另有来源，不作为原创网络结构展示。

## 从零运行普通图片路径

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

锁文件面向 Linux x86_64 / Python 3.12。离线安装可在第一条 pip 命令增加 `--no-index --find-links var/wheels`，wheel 仍须匹配锁内哈希。首次使用需要系统已有 Python 3.12 和 venv 支持。不要复制旧虚拟环境，也不要借用其他项目的解释器。

```bash
.venv/bin/python -m vision_service.api --data-root var/data --port 8001
```

打开 `http://127.0.0.1:8001/docs` 可查看接口。另开同一项目环境的终端：

```bash
.venv/bin/python scripts/demo_client.py --url http://127.0.0.1:8001 --output var/client-first
```

客户端生成一张合成测试图片、申请会话、提交任务、轮询、下载 PNG 并核对 SHA256；也可用 `--image /path/to/image.png` 处理自己的图。输出保留报告和结果，令牌不写进报告。API 绑定回环地址，公开部署需单独的 HTTPS/访问控制/限流方案。

## 真实太阳模型路径

安装独立研究 wheel 和 CPU 依赖到**本项目**虚拟环境：

```bash
.venv/bin/python -m pip install --no-index --find-links var/wheels --find-links var/solar-wheels --require-hashes -r requirements-solar.lock
.venv/bin/python -m vision_service.api --data-root var/data --solar-root var/solar --port 8001
```

`solar-package.json` 指定研究 wheel 版本及哈希，`src/vision_service/solar.py` 校验观测、协议和权重。`var/solar` 需具备获准使用的登记资产；它们不包含在公共源码里。缺资产时普通图片仍可用，太阳能力接口明确返回 unavailable。

## 原理：请求如何成为可核验结果

1. **输入边界**：普通图片最大 4 MiB、100 万像素，只接受静态 PNG/JPEG。服务实际解码，不仅看扩展名。太阳入口只接受登记样例 ID 与允许的目标帧，不能传服务器路径或任意模型。
2. **访问与幂等**：随机 Bearer 令牌标识本地会话，数据库只存令牌派生值。`(owner, idempotency_key)` 唯一；同键同内容返回旧任务，同键不同内容返回 409。令牌是持有即授权，不等同于完整账户系统。
3. **事务与队列**：SQLite 写事务控制插入和最大 10 个在途任务；单 worker 串行取最早任务。数据库保存 queued → running → succeeded/failed 的变化，结果先落盘再发布成功状态。进程锁拒绝同一目录多实例。
4. **模型适配**：普通图片调用 Pillow GaussianBlur(radius=1)。太阳任务调用已安装的研究包，固定 CPU 权重/预处理，输出科学 NPZ 与同色阶 PNG。两者分别标记 classical_baseline / neural_model，像素变化不是质量准确率。
5. **恢复与重试**：启动把遗留 running 标为 interrupted，queued 继续排队。显式重试创建带 retry_of 的新任务，旧失败记录保留；重试前再次核对原始输入哈希。
6. **数据保留**：离线清理仅处理超过保留期的终态任务，先标 expired 再删除相应输入/结果目录，保留元数据。运行中的服务持锁，清理拒绝并发执行；默认只输出 dry run，不会自动删除。

```text
客户端 → 校验/鉴权/幂等 → SQLite 队列 → 单 worker → 固定处理器
              ↑                                  ↓
              └──── 状态、版本、报告、PNG/NPZ 下载 ────┘
```

## 常用接口

| 请求 | 功能 |
| --- | --- |
| POST /api/v1/session | 创建本地访问令牌 |
| POST /api/v1/jobs | 图片原始字节提交，需 Idempotency-Key |
| POST /api/v1/solar/jobs | 登记太阳样例推理 |
| GET /api/v1/jobs/{id} | 查询状态和报告 |
| GET /api/v1/jobs/{id}/result | 下载 PNG |
| GET /api/v1/jobs/{id}/array | 下载太阳科学数组 |
| POST /api/v1/jobs/{id}/retry | 显式重试失败/中断任务 |

停止本项目服务后预览保留策略：

```bash
.venv/bin/python -m vision_service.maintenance --data-root var/data --days 30
```

检查列表并备份后才增加 `--apply` 执行删除；不要对仍需保留的研究数据使用清理命令。

## 验证边界

单机持久队列适合小型 CPU 演示，并非多实例分布式队列。已完成本机独立环境恢复；跨主机/容器与公网攻击面尚未验收。个人贡献是需求选择、已有研究结合及 AI 辅助实现/核验，不应解释成已有企业工程任职。
