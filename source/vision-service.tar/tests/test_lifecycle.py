import time
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from fastapi import HTTPException
from vision_service.api import Store,create_app
from vision_service.maintenance import prune
from test_api import picture,auth,wait

def test_retry_preserves_failed_record_and_authorization(tmp_path):
    store=Store(tmp_path);original=store.submit('owner','first',picture())
    with store.connect() as db:db.execute("UPDATE jobs SET status='failed',error='TEST_FAILURE'")
    child=store.retry(original['id'],'owner','attempt')
    assert child['id']!=original['id'] and child['retry_of']==original['id']
    assert store.retry(original['id'],'owner','attempt')['id']==child['id']
    assert store.get(original['id'],'owner')['status']=='failed'
    with pytest.raises(HTTPException) as e:store.retry(original['id'],'other','attempt')
    assert e.value.status_code==404
    (tmp_path/original['id']/'input.bin').write_bytes(b'changed')
    with pytest.raises(HTTPException) as e:store.retry(original['id'],'owner','next')
    assert e.value.status_code==409

def test_retry_http_and_success_not_retryable(tmp_path):
    with TestClient(create_app(tmp_path)) as c:
        h=auth(c);ident=c.post('/api/v1/jobs',headers=h,content=picture()).json()['job_id']
        assert wait(c,ident,h)['status']=='succeeded'
        assert c.post('/api/v1/jobs/'+ident+'/retry',headers=h).status_code==409
        with Store(tmp_path).connect() as db:db.execute("UPDATE jobs SET status='interrupted' WHERE id=?",(ident,))
        r=c.post('/api/v1/jobs/'+ident+'/retry',headers=h);assert r.status_code==202
        assert r.json()['retry_of']==ident;assert wait(c,r.json()['job_id'],h)['status']=='succeeded'

def test_retention_dry_run_and_active_preserved(tmp_path):
    store=Store(tmp_path);done=store.submit('a','old',picture());active=store.submit('a','active',picture())
    with store.connect() as db:
        db.execute('UPDATE jobs SET created=?',(time.time()-40*86400,));db.execute("UPDATE jobs SET status='succeeded' WHERE id=?",(done['id'],))
    assert prune(tmp_path)['count']==1 and (tmp_path/done['id']).is_dir()
    prune(tmp_path,apply=True)
    assert not (tmp_path/done['id']).exists() and (tmp_path/active['id']).exists()
    assert store.get(done['id'],'a')['status']=='expired'
    with TestClient(create_app(tmp_path)):
        with pytest.raises(BlockingIOError):prune(tmp_path,apply=True)

def test_retention_rejects_path_escape(tmp_path):
    store=Store(tmp_path)
    with store.connect() as db:db.execute("INSERT INTO jobs VALUES (?,?,?,?,?,?,?,?)",('../outside','a','x','digest','failed',0,None,None))
    with pytest.raises(ValueError,match='UNSAFE'):prune(tmp_path,apply=True)
