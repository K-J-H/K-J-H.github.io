import pytest
from fastapi.testclient import TestClient
from vision_service.api import create_app
from vision_service import solar


def test_unconfigured_and_validation(tmp_path):
    with TestClient(create_app(tmp_path,solar_root=tmp_path/'missing')) as c:
        h={'Authorization':'Bearer '+'x'*40,'Idempotency-Key':'a'}
        assert c.get('/api/v1/solar/capability').json()['available'] is False
        assert c.post('/api/v1/solar/jobs',json={'sample_id':solar.SAMPLE},headers=h).status_code==503
        assert c.post('/api/v1/solar/jobs',json={'sample_id':solar.SAMPLE}).status_code==401
        assert c.post('/api/v1/solar/jobs',content=b'x'*1025,headers=h).status_code==413
        for payload in [{'sample_id':'../../secret'},{'sample_id':solar.SAMPLE,'target':True},{'sample_id':solar.SAMPLE,'target':12},{'sample_id':solar.SAMPLE,'path':'anything'},[]]:
            assert c.post('/api/v1/solar/jobs',json=payload,headers=h).status_code==422


def test_canonical_input_versions():
    a=solar.encode({'sample_id':solar.SAMPLE})
    assert a==solar.encode({'target':7,'crop':0,'sample_id':solar.SAMPLE})
    assert a!=solar.encode({'sample_id':solar.SAMPLE,'target':6})
    assert solar.MODEL_SHA.encode() in a and solar.SHA.encode() in a
