import io
import sqlite3
import time
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
from PIL import Image
from vision_service.api import create_app,Store


def picture(value=0,size=(32,32)):
    im=Image.new('RGB',size,(value,0,0));im.putpixel((16,16),(255,255,255));f=io.BytesIO();im.save(f,format='PNG');return f.getvalue()

def auth(client,key='one'):
    return {'Authorization':'Bearer '+client.post('/api/v1/session').json()['token'],'Idempotency-Key':key}

def wait(client,ident,h):
    end=time.monotonic()+5
    while time.monotonic()<end:
        data=client.get('/api/v1/jobs/'+ident,headers=h).json()
        if data['status'] in ('succeeded','failed','interrupted'):return data
        time.sleep(.02)
    raise AssertionError('Worker did not finish')

def test_real_image_dedup_isolation_restart(tmp_path):
    with TestClient(create_app(tmp_path)) as c:
        h=auth(c);r=c.post('/api/v1/jobs',headers=h,content=picture());assert r.status_code==202
        ident=r.json()['job_id'];d=wait(c,ident,h);assert d['status']=='succeeded'
        output=c.get('/api/v1/jobs/'+ident+'/result',headers=h)
        assert output.status_code==200 and output.content!=picture()
        im=Image.open(io.BytesIO(output.content));assert 0<im.getpixel((16,16))[0]<255
        assert d['report']['neural_model'] is False
        assert c.post('/api/v1/jobs',headers=h,content=picture()).json()['job_id']==ident
        assert c.post('/api/v1/jobs',headers=h,content=picture(20)).status_code==409
        assert c.get('/api/v1/jobs/'+ident,headers=auth(c)).status_code==404
        assert c.get('/api/v1/jobs/'+ident+'/result').status_code==401
    with TestClient(create_app(tmp_path)) as c:
        assert c.get('/api/v1/jobs/'+ident,headers=h).json()['status']=='succeeded'
        assert c.get('/api/v1/jobs/'+ident+'/result',headers=h).content==output.content

def test_invalid_and_oversize(tmp_path):
    with TestClient(create_app(tmp_path)) as c:
        h=auth(c)
        assert c.post('/api/v1/jobs',headers=h,content=b'not an image').status_code==422
        assert c.post('/api/v1/jobs',headers=h,content=b'x'*(4*1024*1024+1)).status_code==413
        assert c.post('/api/v1/jobs',headers=h,content=picture(size=(1100,1100))).status_code==413
        assert c.post('/api/v1/jobs?method_id=shine',headers=h,content=picture()).status_code==422

def test_concurrent_idempotency(tmp_path):
    store=Store(tmp_path)
    with ThreadPoolExecutor(max_workers=4) as pool:
        ids=list(pool.map(lambda _:store.submit('a','same',picture())['id'],range(4)))
    assert len(set(ids))==1

def test_queue_bound_and_interrupted(tmp_path):
    store=Store(tmp_path)
    for i in range(10):store.submit('a',str(i),picture())
    import pytest
    from fastapi import HTTPException
    with pytest.raises(HTTPException) as exc:store.submit('b','11',picture())
    assert exc.value.status_code==429
    with store.connect() as db:db.execute("UPDATE jobs SET status='running'")
    with TestClient(create_app(tmp_path)):
        with store.connect() as db:assert db.execute("SELECT count(*) FROM jobs WHERE status='interrupted'").fetchone()[0]==10
