# Vision inference and asynchronous task service

[中文](README.md) · [Migration](docs/RUNBOOK.md)

A small, inspectable service that turns image experiments into validated submissions, persistent task states and downloadable evidence. Ordinary PNG/JPEG uploads use a classical Gaussian baseline. Registered solar samples use real SHINE CPU inference. These routes are deliberately distinct.

Reviewers can inspect FastAPI contracts, SQLite transactions, idempotency, access-scoped results, explicit retry lineage, retention and model provenance. Twelve service tests and a separate real-weight/HTTP consistency check have passed. This is an AI-assisted personal prototype, without claimed production traffic or commercial SLA.

## Install and verify from scratch

Tested target: Linux x86_64 with Python 3.12 and venv support. In this repository:

```bash
python3.12 -m venv .venv
.venv/bin/python -m pip install --require-hashes -r requirements.lock
.venv/bin/python -m pip install --no-build-isolation --no-deps .
.venv/bin/python -m pytest -q
```

For an offline installation, add `--no-index --find-links var/wheels` to the dependency installation command and supply the exact locked wheels. Recreate the environment; do not copy an old venv or use a sibling project's interpreter.

## Start and exercise the complete ordinary-image path

```bash
.venv/bin/python -m vision_service.api --data-root var/data --port 8001
```

In another terminal using the same project environment:

```bash
.venv/bin/python scripts/demo_client.py --url http://127.0.0.1:8001 --output var/client-first
```

The client creates a labelled synthetic test image, obtains a token, submits/polls a real task, downloads the result and verifies its hash. Supply `--image /path/image.png` to use your own image. The output directory must be new. API documentation is at `http://127.0.0.1:8001/docs`.

For solar inference, supply permitted assets in `var/solar` and exact wheels in `var/solar-wheels` matching `solar-package.json` and `requirements-solar.lock`:

```bash
.venv/bin/python -m pip install --no-index --find-links var/wheels --find-links var/solar-wheels --require-hashes -r requirements-solar.lock
.venv/bin/python -m vision_service.api --data-root var/data --solar-root var/solar --port 8001
```

## Why each stage exists

1. **Validate:** decode static PNG/JPEG, cap requests at 4 MiB and one million pixels. The solar route accepts registered IDs and permitted frame indices, not paths or arbitrary models.
2. **Identify and deduplicate:** bearer possession controls a session's jobs; only a derived owner value is stored. `(owner, idempotency_key)` is unique. Same key/content returns the same job; changed content returns 409. This is not a full user-account system.
3. **Queue transactionally:** at most ten queued/running jobs; one worker claims the oldest queued item. An exclusive process lock prevents concurrent workers using the same data directory. Files are finalized before publishing success.
4. **Process reproducibly:** Gaussian radius=1 for ordinary images; an independently installed, versioned research package for fixed solar inference. Reports distinguish classical and neural processing and retain input/model provenance. Pixel change is not accuracy.
5. **Recover explicitly:** restart marks stale running jobs interrupted and continues queued jobs. Retry creates a child task with `retry_of`, preserves the original failure and rechecks input hash.
6. **Retain deliberately:** offline maintenance previews terminal jobs older than the policy, then optionally marks them expired and removes only validated task directories. Active jobs are excluded. Run `python -m vision_service.maintenance --data-root var/data --days 30` in the venv; `--apply` is destructive and should follow review and backup.

Endpoints: `POST /api/v1/session`, `POST /api/v1/jobs`, `POST /api/v1/solar/jobs`, `GET /api/v1/jobs/{id}`, `/result`, `/array`, and `POST /api/v1/jobs/{id}/retry`. Job requests require Bearer authorization; submissions/retries also require Idempotency-Key.

The service binds localhost. Public HTTPS, authentication, abuse limits and cross-host deployment remain separate acceptance work. The persisted single-worker queue is suitable for a small CPU demo, not a distributed production claim.
